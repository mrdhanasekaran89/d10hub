<?php

declare(strict_types=1);

namespace Drupal\rlt_volume_calculator_items\Entity;

use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\RevisionableContentEntityBase;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\rlt_volume_calculator_items\RltVolumeCalculatorItemsInterface;
use Drupal\user\EntityOwnerTrait;

/**
 * Defines the rlt volume calculator item entity class.
 *
 * @ContentEntityType(
 *   id = "rlt_volume_calculator_items",
 *   label = @Translation("RLT Volume calculator item"),
 *   label_collection = @Translation("RLT Volume calculator item"),
 *   label_singular = @Translation("rlt Volume calculator item"),
 *   label_plural = @Translation("rlt Volume calculator items"),
 *   label_count = @PluralTranslation(
 *     singular = "@count rlt Volume calculator item",
 *     plural = "@count rlt Volume calculator items",
 *   ),
 *   handlers = {
 *     "storage" = "Drupal\Core\Entity\Sql\SqlContentEntityStorage",
 *     "list_builder" = "Drupal\rlt_volume_calculator_items\RltVolumeCalculatorItemsListBuilder",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "form" = {
 *       "add" = "Drupal\rlt_volume_calculator_items\Form\RltVolumeCalculatorItemsForm",
 *       "edit" = "Drupal\rlt_volume_calculator_items\Form\RltVolumeCalculatorItemsForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *       "delete-multiple-confirm" = "Drupal\Core\Entity\Form\DeleteMultipleForm",
 *       "revision-delete" = \Drupal\Core\Entity\Form\RevisionDeleteForm::class,
 *       "revision-revert" = \Drupal\Core\Entity\Form\RevisionRevertForm::class,
 *     },
 *     "route_provider" = {
 *       "default" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *       "revision" = \Drupal\Core\Entity\Routing\RevisionHtmlRouteProvider::class,
 *     },
 *   },
 *   base_table = "rlt_volume_calculator_items",
 *   data_table = "rlt_volume_calculator_items_field_data",
 *   revision_table = "rlt_volume_calculator_items_revision",
 *   revision_data_table = "rlt_volume_calculator_items_field_revision",
 *   show_revision_ui = TRUE,
 *   translatable = TRUE,
 *   admin_permission = "administer rlt_volume_calculator_items",
 *   entity_keys = {
 *     "id" = "id",
 *     "revision" = "revision_id",
 *     "langcode" = "langcode",
 *     "label" = "classification",
 *     "uuid" = "uuid",
 *     "owner" = "uid",
 *   },
 *   revision_metadata_keys = {
 *     "revision_user" = "revision_uid",
 *     "revision_created" = "revision_timestamp",
 *     "revision_log_message" = "revision_log",
 *   },
 *   links = {
 *     "collection" = "/admin/content/volume-calculator-items",
 *     "add-form" = "/volume-calculator-items/add",
 *     "canonical" = "/volume-calculator-items/{rlt_volume_calculator_items}",
 *     "edit-form" = "/volume-calculator-items/{rlt_volume_calculator_items}/edit",
 *     "delete-form" = "/volume-calculator-items/{rlt_volume_calculator_items}/delete",
 *     "delete-multiple-form" = "/admin/content/volume-calculator-items/delete-multiple",
 *     "revision" = "/volume-calculator-items/{rlt_volume_calculator_items}/revision/{item_revision}/view",
 *     "revision-delete-form" = "/volume-calculator-items/{rlt_volume_calculator_items}/revision/{item_revision}/delete",
 *     "revision-revert-form" = "/volume-calculator-items/{rlt_volume_calculator_items}/revision/{item_revision}/revert",
 *     "version-history" = "/volume-calculator-items/{rlt_volume_calculator_items}/revisions",
 *   },
 * )
 */
final class RltVolumeCalculatorItems extends RevisionableContentEntityBase implements RltVolumeCalculatorItemsInterface {

  use EntityChangedTrait;
  use EntityOwnerTrait;

  /**
   * {@inheritdoc}
   */
  public function preSave(EntityStorageInterface $storage): void {
    parent::preSave($storage);
    if (!$this->getOwnerId()) {
      // If no owner has been set explicitly, make the anonymous user the owner.
      $this->setOwnerId(0);
    }
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type): array {

    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['classification'] = BaseFieldDefinition::create('string')
      ->setRevisionable(TRUE)
      ->setTranslatable(TRUE)
      ->setLabel(t('Classification'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['item'] = BaseFieldDefinition::create('string_long')
      ->setRevisionable(TRUE)
      ->setTranslatable(TRUE)
      ->setLabel(t('Item'))
      ->setRequired(FALSE)
      ->setDisplayOptions('form', [
        'type' => 'text_textarea',
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'text_long',
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['score'] = BaseFieldDefinition::create('string')
      ->setRevisionable(TRUE)
      ->setTranslatable(TRUE)
      ->setLabel(t('Score'))
      ->setSetting('max_length', 255)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
      ])
      ->setDisplayConfigurable('view', TRUE);

      $terms = \Drupal::entityTypeManager()
        ->getStorage('taxonomy_term')->loadTree('addition_method', 0, 1, TRUE);
      $options = [];
      if(!empty($terms)) {
        foreach ($terms as $term) {
          $options[$term->id()] = $term->getName();
        }
      }

    $fields['addition_method'] = BaseFieldDefinition::create('list_integer')
      ->setRevisionable(TRUE)
      ->setTranslatable(TRUE)
      ->setLabel(t('Addition method'))
      ->setSettings([
        'allowed_values' => $options,
      ])
      ->setDisplayOptions('view', [
        'label' => 'visible',
        'type' => 'list_default',
      ])
      ->setDisplayOptions('form', [
        'type' => 'options_select',
      ])
      ->setDisplayConfigurable('view', TRUE)
      ->setDisplayConfigurable('form', TRUE);

    $fields['remarks'] = BaseFieldDefinition::create('string')
      ->setRevisionable(TRUE)
      ->setTranslatable(TRUE)
      ->setLabel(t('Remarks'))
      ->setSetting('max_length', 255)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['type'] = BaseFieldDefinition::create('list_string')
      ->setLabel(t('Calculator Type'))
      ->setSettings([
        'allowed_values' => [
          'volume' => 'Volume',
          'dpc' => 'DPC',
          'pluvicto' => 'Pluvicto',
        ],
      ])
      ->setDisplayOptions('view', [
        'label' => 'visible',
        'type' => 'list_default',
      ])
      ->setDisplayOptions('form', [
        'type' => 'options_select',
      ])
      ->setDisplayConfigurable('view', TRUE)
      ->setDisplayConfigurable('form', TRUE);

    $fields['uid'] = BaseFieldDefinition::create('entity_reference')
      ->setRevisionable(TRUE)
      ->setTranslatable(TRUE)
      ->setLabel(t('Author'))
      ->setSetting('target_type', 'user')
      ->setDefaultValueCallback(self::class . '::getDefaultEntityOwner')
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator' => 'CONTAINS',
          'size' => 60,
          'placeholder' => '',
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'author',
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Authored on'))
      ->setTranslatable(TRUE)
      ->setDescription(t('The time that the rlt Volume calculator item was created.'))
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'timestamp',
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('form', [
        'type' => 'datetime_timestamp',
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
      ->setTranslatable(TRUE)
      ->setDescription(t('The time that the rlt Volume calculator item was last edited.'));

    return $fields;
  }

}
