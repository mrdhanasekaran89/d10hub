<?php

namespace Drupal\rlt_volume_calculator_items\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'Rlt Core' block.
 *
 * @Block(
 *   id = "rlt_dpc_simulation_block",
 *   admin_label = @Translation("Rlt DPC Simulation Block"),
 *   category = @Translation("Rlt DPC Simulation Block")
 * )
 */
class RltDPCSimulationBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The form builder.
   */
  protected FormBuilderInterface $formBuilder;

  /**
   * {@inheritdoc}
   *
   * This block provides a form for RLT Stimulation, which is dynamically
   * rendered and does not use caching to ensure the content is always
   * up-to-date.
   */
  public function __construct(
    array $configuration,
    string $plugin_id,
    mixed $plugin_definition,
    FormBuilderInterface $form_builder,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->formBuilder = $form_builder;
  }

  /**
   * {@inheritdoc}
   *
   * This method is used to create an instance of the block plugin
   * using the service container. It ensures that the required
   * dependencies are injected into the block.
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('form_builder')
    );
  }

  /**
   * {@inheritdoc}
   * Disable caching for this form to ensure dynamic content is always up-to-date.
   */
  public function getCacheMaxAge() {
    return 0;
  }

  /**
   * {@inheritdoc}
   *
   * This method is used to define the behavior of the block when it is rendered.
   * It ensures that the block content is dynamically generated and up-to-date.
   */
  public function build() {
    $form = $this->formBuilder->getForm('Drupal\rlt_volume_calculator_items\Form\RltDpcSimulation');
    return $form;
  }

}
