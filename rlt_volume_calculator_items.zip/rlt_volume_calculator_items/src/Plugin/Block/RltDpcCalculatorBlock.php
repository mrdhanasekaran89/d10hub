<?php

namespace Drupal\rlt_volume_calculator_items\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'Rlt Core' block.
 *
 * @Block(
 *   id = "rlt_dpc_calculator_block",
 *   admin_label = @Translation("Rlt DPC Calculator"),
 *   category = @Translation("Rlt Custom DPC Calculator block")
 * )
 */
class RltDpcCalculatorBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The form builder.
   *
   * This service is used to render the custom form associated with the block.
   */
  protected FormBuilderInterface $formBuilder;

  /**
   * Constructs a new RltVolumeCalculatorBlock instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Form\FormBuilderInterface $form_builder
   *   The form builder service.
   */
  public function __construct(
    array $configuration,
    string $plugin_id,
    mixed $plugin_definition,
    FormBuilderInterface $form_builder,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->formBuilder = $form_builder;
  }

  /**
   * Creates an instance of the block plugin.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The service container.
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   *
   * @return static
   *   Returns an instance of the block plugin.
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('form_builder')
    );
  }

  /**
   * {@inheritdoc}
   * Disable caching for this form to ensure dynamic content is always up-to-date.
   */
  public function getCacheMaxAge() {
    return 0;
  }

  /**
   * Builds the block content.
   *
   * @return array
   *   A render array representing the block content.
   */
  public function build() {
    $form = $this->formBuilder->getForm('Drupal\rlt_volume_calculator_items\Form\RltDpcCalculator');
    return $form;
  }

}
