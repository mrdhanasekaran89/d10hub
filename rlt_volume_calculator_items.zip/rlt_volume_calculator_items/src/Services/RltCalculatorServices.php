<?php

namespace Drupal\rlt_volume_calculator_items\Services;

use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Objects, properties, and methods to communicate with the Salesforce API.
 */
class RltCalculatorServices {
  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructor which initializes the consumer.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * Get all taxonomy terms by vocabulary ID.
   *
   * @param string $vid
   *   The vocabulary ID.
   *
   * @return array
   *   An array of taxonomy terms.
   */
  public function getTaxonomyTermsByVid($vid, $tid = NULL, $calculator_type = NULL) {
    $storage = $this->entityTypeManager->getStorage('taxonomy_term');
    if ($tid) {
      return $this->getSingleTermName($storage, $tid);
    }
    $terms = $storage->loadTree($vid);
    $term_list = [];
    foreach ($terms as $term) {
      if ($term->status == "1") {
        $this->addTermToList($term_list, $storage, $term, $calculator_type);
      }
    }
    return $term_list;
  }

  /**
   * Helper to get the name of a single term if published.
   */
  private function getSingleTermName($storage, $tid) {
    $term = $storage->load($tid);
    if ($term && $term->isPublished()) {
      return $term->getName();
    }
    return [];
  }

  /**
   * Helper to add a term to the list based on calculator_type.
   */
  private function addTermToList(array &$term_list, $storage, $term, $calculator_type) {
    $term_entity = $storage->load($term->tid);
    if ($calculator_type !== NULL && $term_entity && $term_entity->hasField('calculator_type')) {
      $calculator_type_data = array_column($term_entity->get('calculator_type')->getValue(), 'value');
      if (in_array($calculator_type, $calculator_type_data)) {
        $term_list[$term->name] = $term->name;
      }
    }
    elseif ($term_entity) {
      $term_list[$term->name] = $term->name;
    }
  }

  /**
   * Filter entities based on the length of hospital stay.
   *
   * @param array $entities
   *   The array of entities to filter.
   * @param int $length_of_hospital
   *   The selected length of hospital stay.
   *
   * @return array
   *   The filtered array of entities.
   */
  public function filterEntities(array $entities, $length_of_hospital) {
    $keys = array_keys($entities);
    if ($length_of_hospital == 1) {
      unset($entities[$keys[1]], $entities[$keys[2]]);
    }
    elseif ($length_of_hospital == 2) {
      unset($entities[$keys[2]]);
    }
    elseif ($length_of_hospital == 3) {
      unset($entities[$keys[2]]);
      $entities[] = $entities[$keys[1]];
    }
    elseif ($length_of_hospital == 4) {
      $entities[] = $entities[$keys[1]];
    }
    elseif ($length_of_hospital == 5) {
      $entities[] = $entities[$keys[1]];
      $entities[] = $entities[$keys[2]];
    }
    return $entities;
  }

  /**
   * Calculate medical fee points and daily average volume.
   *
   * @param int $length_of_hospital
   *   The selected length of hospital stay.
   *
   * @return array
   *   An array containing medical fee points and daily average volume.
   */
  public function calculateMedicalFeePointsDpc($length_of_hospital) {
    return $this->calculatePoints($length_of_hospital, 'dpc');
  }

  /**
   * Calculate medical fee points and daily average volume.
   *
   * @param int $length_of_hospital
   *   The selected length of hospital stay.
   *
   * @return array
   *   An array containing medical fee points and daily average volume.
   */
  public function calculateMedicalFeePointsVolume($length_of_hospital) {
    return $this->calculatePoints($length_of_hospital, 'volume', TRUE);
  }

  /**
   * Calculate medical fee points and daily average volume.
   *
   * @param int $length_of_hospital
   *   The selected length of hospital stay.
   *
   * @return array
   *   An array containing medical fee points and daily average volume.
   */
  public function calculateMedicalFeePointsPluvicto($length_of_hospital) {
    return $this->calculatePoints($length_of_hospital, 'pluvicto', TRUE);
  }

  /**
   * Common function to calculate medical fee points and daily average volume.
   *
   * @param int $length_of_hospital
   *   The selected length of hospital stay.
   * @param string $type
   *   The type of entities to query ('dpc' or 'volume').
   * @param bool $isVolume
   *   Whether the calculation is for volume.
   *
   * @return array
   *   An array containing medical fee points and daily average volume.
   */
  public function calculatePoints($length_of_hospital, $type, $isVolume = FALSE) {
    $medical_fee_points = 0;
    $entities = $this->getClassification($type, $length_of_hospital, $isVolume);
    foreach ($entities as $entity) {
      $score = $entity->get('score')->value ?? 0;
      $addition_method = $entity->get('addition_method')->value ?? '0';
      $method = $this->getTaxonomyTermsByVid('addition_method', $addition_method) ?: ($isVolume ? 'D' : 'A');
      if ($method === 'W') {
        $medical_fee_points += $score * ceil($length_of_hospital / 7);
      }
      elseif ($method === 'D') {
        $medical_fee_points += $score * $length_of_hospital;
      }
      else {
        $medical_fee_points += $score;
      }
    }
    $daily_average_volume = $length_of_hospital > 0
      ? ($isVolume
        ? ceil($medical_fee_points * 10 / $length_of_hospital)
        : $medical_fee_points / $length_of_hospital)
      : 0;
    return [
      'medical_fee_points' => number_format($medical_fee_points),
      'daily_average_volume' => number_format($daily_average_volume),
    ];
  }

  /**
   * Get classification entities based on type and filter if necessary.
   *
   * @param string $type
   *   The type of entities to query ('dpc' or 'volume').
   * @param int $length_of_hospital
   *   The selected length of hospital stay.
   * @param bool $isVolume
   *   Whether the calculation is for volume.
   *
   * @return array
   *   The array of classification entities.
   */
  public function getClassification($type, $length_of_hospital, $isVolume = FALSE) {
    $storage = $this->entityTypeManager->getStorage('rlt_volume_calculator_items');
    $query = $storage->getQuery()->accessCheck(FALSE)->condition('type', $type);
    $entities = $storage->loadMultiple($query->execute());
    if (!$isVolume) {
      $entities = $this->filterEntities($entities, $length_of_hospital);
    }
    return $entities;
  }
}
