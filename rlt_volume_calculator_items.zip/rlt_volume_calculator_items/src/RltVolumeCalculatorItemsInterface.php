<?php

declare(strict_types=1);

namespace Drupal\rlt_volume_calculator_items;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface defining a rlt user data entity type.
 */
interface RltVolumeCalculatorItemsInterface extends ContentEntityInterface, EntityOwnerInterface, EntityChangedInterface {

}
