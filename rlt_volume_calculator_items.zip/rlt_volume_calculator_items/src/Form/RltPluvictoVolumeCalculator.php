<?php

namespace Drupal\rlt_volume_calculator_items\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\CssCommand;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\rlt_volume_calculator_items\Services\RltCalculatorServices;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * {@inheritdoc}
 */
class RltPluvictoVolumeCalculator extends FormBase {

  /**
   * The configuration factory service.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The RltCalculatorServices service.
   *
   * @var \Drupal\rlt_volume_calculator_items\Services\RltCalculatorServices
   */
  protected $calculatorService;

  /**
   * Constructs a new RltPluvictoVolumeCalculator object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\rlt_volume_calculator_items\Services\RltCalculatorServices $calculatorService
   *   The calculator service.
   */
  public function __construct(ConfigFactoryInterface $config_factory, RltCalculatorServices $calculatorService) {
    $this->configFactory = $config_factory;
    $this->calculatorService = $calculatorService;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('rlt_volume_calculator_items.calculator_services')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'rlt_pluvicto_volume_calculator';
  }

  /**
   * Build the custom form.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   The built form.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->configFactory->get('rlt_volume_calculator_items.dpc_settings');
    // Calculator labels.
    $pluvicto_calculator_title = $config->get('pluvicto_calculator_title') != null ? $this->t($config->get('pluvicto_calculator_title')) : $this->t('Pluvicto Volume calculation');
    $income_title = $config->get('income_title') != null ? $this->t($config->get('income_title')) : $this->t('Income');
    $expenses_title = $config->get('expenses_title') != null ? $this->t($config->get('expenses_title')) : $this->t('Expenses');
    $run_simulation_text = $config->get('run_simulation_text') != null ? $this->t($config->get('run_simulation_text')) : $this->t('Run Simulation');
    $items_required_description = $config->get('items_required_description') != null ? $this->t($config->get('items_required_description')) : $this->t('**Major items required as initial investment');
    $pluvicto_hospitalization_period_text = $config->get('pluvicto_hospitalization_period_text') != null ? $this->t($config->get('pluvicto_hospitalization_period_text')) : $this->t('Hospitalization period after Pluvicto treatment');
    $pluvicto_hosp_period_days_text = $config->get('pluvicto_hosp_period_days_text') != null ? $this->t($config->get('pluvicto_hosp_period_days_text')) : $this->t('Days');
    $pluvicto_reimbursement_points_text = $config->get('pluvicto_reimbursement_points_text') != null ? $this->t($config->get('pluvicto_reimbursement_points_text')) : $this->t('Reimbursement Points (Hospitalization Period)');
    $pluvicto_reimbursement_points_right_text = $config->get('pluvicto_reimbursement_points_right_text') != null ? $this->t($config->get('pluvicto_reimbursement_points_right_text')) : $this->t('Points (Length of hospital stay)');
    $pluvicto_daily_average_text = $config->get('pluvicto_daily_average_text') != null ? $this->t($config->get('pluvicto_daily_average_text')) : $this->t('Daily Average Fee-for-Service') . ' <span class="description">' . $this->t('(Yen Conversion)') . '</span>';
    $pluvicto_room_preparation_text = $config->get('pluvicto_room_preparation_text') != null ? $this->t($config->get('pluvicto_room_preparation_text')) : $this->t('Room Preparation and Cleaning Costs') . ' <span class="description">' . $this->t('Yen (per hospitalization)') . '</span>';
    $pluvicto_room_preparation_select_text = $config->get('pluvicto_room_preparation_select_text') != null ? $this->t($config->get('pluvicto_room_preparation_select_text')) : $this->t('Room Preparation and Cleaning Fee');
    $pluvicto_initial_investment_text = $config->get('pluvicto_initial_investment_text') != null ? $this->t($config->get('pluvicto_initial_investment_text')) : $this->t('Initial Investment Amount**') . ' <span class="description">' . $this->t('Yen') . '</span>';
    $pluvicto_initial_investment_select_text = $config->get('pluvicto_initial_investment_select_text') != null ? $this->t($config->get('pluvicto_initial_investment_select_text')) : $this->t('Initial Investment');

    $form['#prefix'] = '<div class="content"><div class="medical-fee-calculator input volume-calculation">';
    $form['#suffix'] = '</div></div>';

    $form['#attached']['html_head'][] = [
      [
        '#tag' => 'style',
        '#value' => '#block-rltpluvictosimulationblock, .download-pdf-wrapper { display: none; }',
      ],
      'hide-block-css',
    ];

    $form['pluvicto_volume_header'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-header']],
    ];

    $form['pluvicto_volume_header']['left'] = [
      '#type' => 'markup',
      '#markup' => '<h4 class="strong">' . $pluvicto_calculator_title . '</h4>',
    ];

    $form['pluvicto_income_header'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-header-row']],
      'content' => [
        '#markup' => $income_title,
      ],
    ];

    // Length of hospital stay field.
    $form['pluvicto_length_of_stay'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row', 'length-of-stay']],
    ];

    $form['pluvicto_length_of_stay']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => $pluvicto_hospitalization_period_text,
      ],
    ];
    $form['pluvicto_length_of_stay']['right_part'] = [
      '#type' => 'select',
      '#title' => $pluvicto_hosp_period_days_text,
      '#options' => $this->calculatorService->getTaxonomyTermsByVid('length_of_hospital_stay', NULL, 'pluvicto'),
      '#attributes' => ['class' => ['form-select', 'length-of-stay-select']],
      '#label_attributes' => ['class' => ['form-required']],
      '#ajax' => [
        'callback' => '::updateMedicalFeePoints',
        'event' => 'change',
        'wrapper' => 'pluvicto-ajax-wrapper',
      ],
    ];

    $form['pluvicto_ajax_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'pluvicto-ajax-wrapper'],
    ];

    $form['pluvicto_ajax_wrapper']['medical_fee_points'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row', 'field-data']],
    ];

    $form['pluvicto_ajax_wrapper']['medical_fee_points']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => $pluvicto_reimbursement_points_text,
      ],
    ];

    $form['pluvicto_ajax_wrapper']['medical_fee_points']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part'], 'id' => ['medical-fee-points']],
      '#markup' => '<div class="medical-fee-points-wrapper hidden"><h4>16,926</h4><span class="description">' . $pluvicto_reimbursement_points_right_text . '</span></div>',
    ];

    $form['pluvicto_ajax_wrapper']['daily_average_volume'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row', 'field-data']],
    ];

    $form['pluvicto_ajax_wrapper']['daily_average_volume']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      '#markup' => $pluvicto_daily_average_text,
    ];

    $form['pluvicto_ajax_wrapper']['daily_average_volume']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part'], 'id' => ['daily-average-volume']],
      '#markup' => '<div class="count-value"><h4 class="hidden">169,260 ' . $this->t('Yen') . '</h4></div>',
    ];

    $form['pluvicto_expenses_header'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-header-row', 'mt-4']],
      'content' => [
        '#markup' => $expenses_title,
      ],
    ];

    $form['pluvicto_room_preparation_fee'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row']],
    ];

    $form['pluvicto_room_preparation_fee']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => $pluvicto_room_preparation_text,
      ],
    ];

    $form['pluvicto_room_preparation_fee']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part'], 'id' => ['room-preparation-fee']],
    ];

    $form['pluvicto_room_preparation_fee']['right_part']['pluvicto_room_preparation_fee_select'] = [
      '#type' => 'select',
      '#title' => $pluvicto_room_preparation_select_text,
      '#options' => $this->calculatorService->getTaxonomyTermsByVid('room_preparation_and_cleaning_fe', NULL, 'pluvicto'),
      '#attributes' => ['class' => ['form-select', 'preparation-and-cleaning-select']],
    ];

    $form['pluvicto_initial_investment'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row']],
    ];

    $form['pluvicto_initial_investment']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => $pluvicto_initial_investment_text,
      ],
    ];

    $form['pluvicto_initial_investment']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part'], 'id' => ['initial-investment']],
    ];

    $form['pluvicto_initial_investment']['right_part']['pluvicto_initial_investment_select'] = [
      '#type' => 'select',
      '#title' => $pluvicto_initial_investment_select_text,
      '#options' => $this->calculatorService->getTaxonomyTermsByVid('initial_investment', NULL, 'pluvicto'),
      '#attributes' => ['class' => ['form-select', 'initial-investment-select']],
    ];

    // Add CSS to control visibility of blocks initially.
    $form['#attached']['html_head'][] = [
      [
        '#tag' => 'style',
        '#value' => '.hidden { display: none; }',
      ],
      'pluvicto-volume-calculator-initial-css',
    ];
    $form['pluvicto_table_parent'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row last']],
    ];
    $terms = $this->calculatorService->getTaxonomyTermsByVid('intial_investment_items', NULL, 'pluvicto');
    $terms_markup = '<ul>';
    foreach ($terms as $term) {
      $terms_markup .= '<li>' . $this->t($term) . '</li>';
    }
    $terms_markup .= '</ul>';

    $form['pluvicto_table_parent']['table_footer'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-footer']],
      'content' => [
        '#markup' => '<p><strong>' . $items_required_description . '</strong></p>' . $terms_markup,
      ],
    ];
    $form['actions'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['form-action']],
    ];

    $form['actions']['button'] = [
      '#type' => 'button',
      '#value' => $run_simulation_text,
      '#attributes' => ['class' => ['btn', 'btn-primary', 'form-control', 'pluvicto-calculator-submit']]
    ];
    $form['#attached']['library'][] = 'rlt_volume_calculator_items/simulation';
    return $form;
  }

  /**
   * Ajax callback to update medical fee points and daily average volume.
   */
  public function updateMedicalFeePoints(array &$form, FormStateInterface $form_state) {
    $config = $this->configFactory->get('rlt_volume_calculator_items.dpc_settings');
    $pluvicto_reimbursement_points_right_text = $config->get('pluvicto_reimbursement_points_right_text') != null ? $this->t($config->get('pluvicto_reimbursement_points_right_text')) : $this->t('Points (Length of hospital stay)');
    $length_of_hospital = $form_state->getValue(['right_part']);
    if(!empty($length_of_hospital) && is_numeric($length_of_hospital)) {
      $calculatePoints = $this->calculatorService->calculateMedicalFeePointsPluvicto($length_of_hospital);
      $medical_fee_points = $calculatePoints['medical_fee_points'];
      $daily_average_volume = $calculatePoints['daily_average_volume'];
      $form['pluvicto_ajax_wrapper']['medical_fee_points']['right_part']['#markup'] = '<div class="medical-fee-points-wrapper d-flex align-items-center gap-2"><h4>' . $medical_fee_points . '</h4><span class="description">' . $pluvicto_reimbursement_points_right_text . '</span></div>';
      $form['pluvicto_ajax_wrapper']['daily_average_volume']['right_part']['#markup'] = '<div class="medical-fee-points-wrapper"><h4>' . $daily_average_volume . ' ' . $this->t('Yen') . '</h4></div>';
    } else {
      $form['pluvicto_ajax_wrapper']['medical_fee_points']['right_part']['#markup'] = '<div class="medical-fee-points-wrapper d-flex align-items-center gap-2"></div>';
      $form['pluvicto_ajax_wrapper']['daily_average_volume']['right_part']['#markup'] = '<div class="medical-fee-points-wrapper"></div>';
    }
    
    $response = new AjaxResponse();
    $response->addCommand(new CssCommand('#block-rltpluvictosimulationblock, .download-pdf-wrapper', ['display' => 'none']));
    $response->addCommand(new HtmlCommand('#pluvicto-ajax-wrapper', $form['pluvicto_ajax_wrapper']));
    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
  }

}
