<?php

namespace Drupal\rlt_volume_calculator_items\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class RltCustomDrugCostSettingsForm.
 */
class RltCustomDrugCostSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'rlt_volume_calculator_items.dpc_settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'rlt_dpc_calculator_drug_cost_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('rlt_volume_calculator_items.dpc_settings');
    // Common settings.
    $form['common_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Common settings for calculator and simulation'),
      '#open' => FALSE,
    ];
    $form['common_settings']['simulation_results_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Simulation results label'),
      '#description' => $this->t('Enter the Simulation results label'),
      '#default_value' => $config->get('simulation_results_label') !== null ? $config->get('simulation_results_label') : ''
    ];
    $form['common_settings']['simulation_results_download_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Simulation results download label'),
      '#description' => $this->t('Enter the Simulation results download label'),
      '#default_value' => $config->get('simulation_results_download_label') !== null ? $config->get('simulation_results_download_label') : ''
    ];
    $form['common_settings']['income_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Income label'),
      '#description' => $this->t('Enter the Income label'),
      '#default_value' => $config->get('income_title') !== null ? $config->get('income_title') : ''
    ];
    $form['common_settings']['expenses_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Expenses label'),
      '#description' => $this->t('Enter the Expenses label'),
      '#default_value' => $config->get('expenses_title') !== null ? $config->get('expenses_title') : ''
    ];
    $form['common_settings']['items_required_description'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Major items required as initial investment label'),
      '#description' => $this->t('Enter the Major items required as initial investment label'),
      '#default_value' => $config->get('items_required_description') !== null ? $config->get('items_required_description') : ''
    ];
    $form['common_settings']['run_simulation_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Run simulation label'),
      '#description' => $this->t('Enter the Run simulation label'),
      '#default_value' => $config->get('run_simulation_text') !== null ? $config->get('run_simulation_text') : ''
    ];
    // Simulations Items labels.
    $form['simulations_items_labels'] = [
      '#type' => 'details',
      '#title' => $this->t('Simulation Items Labels'),
      '#open' => FALSE,
    ];
    $form['simulations_items_labels']['classification_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Classification Label'),
      '#description' => $this->t('Enter the Classification label'),
      '#default_value' => $config->get('classification_label') !== null ? $config->get('classification_label') : '',
    ];
    $form['simulations_items_labels']['item_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Item Label'),
      '#description' => $this->t('Enter the Item label'),
      '#default_value' => $config->get('item_label') !== null ? $config->get('item_label') : '',
    ];
    $form['simulations_items_labels']['score_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Score Label'),
      '#description' => $this->t('Enter the Score label'),
      '#default_value' => $config->get('score_label') !== null ? $config->get('score_label') : '',
    ];
    $form['simulations_items_labels']['addition_method_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Addition Method Label'),
      '#description' => $this->t('Enter the Addition Method label'),
      '#default_value' => $config->get('addition_method_label') !== null ? $config->get('addition_method_label') : '',
    ];
    $form['simulations_items_labels']['hospitalization_period_points_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Hospitalization Period Points Label'),
      '#description' => $this->t('Enter the Hospitalization Period Points label'),
      '#default_value' => $config->get('hospitalization_period_points_label') !== null ? $config->get('hospitalization_period_points_label') : '',
    ];
    $form['simulations_items_labels']['remarks_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Remarks Label'),
      '#description' => $this->t('Enter the Remarks label'),
      '#default_value' => $config->get('remarks_label') !== null ? $config->get('remarks_label') : '',
    ];
    // Volume Calculator field group.
    $form['volume_calculator'] = [
      '#type' => 'details',
      '#title' => $this->t('Volume Calculator labels'),
      '#open' => FALSE,
    ];
    $form['volume_calculator']['volume_calculator_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Volume calculator title'),
      '#description' => $this->t('Enter the Volume calculator title'),
      '#default_value' => $config->get('volume_calculator_title') !== null ? $config->get('volume_calculator_title') : ''
    ];
    // Calculator section.
    $form['volume_calculator']['volume_hospitalization_period_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Length of hospital stay after Lutathera treatment label'),
      '#description' => $this->t('Enter the Length of hospital stay after Lutathera treatment label'),
      '#default_value' => $config->get('volume_hospitalization_period_text') !== null ? $config->get('volume_hospitalization_period_text') : '',
    ];
    $form['volume_calculator']['volume_hosp_period_days_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Length of hospital stay after Lutathera treatment select label'),
      '#description' => $this->t('Enter the Length of hospital stay after Lutathera treatment select label'),
      '#default_value' => $config->get('volume_hosp_period_days_text') !== null ? $config->get('volume_hosp_period_days_text') : ''
    ];
    $form['volume_calculator']['volume_reimbursement_points_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical fee points label'),
      '#description' => $this->t('Enter the Medical fee points label'),
      '#default_value' => $config->get('volume_reimbursement_points_text') !== null ? $config->get('volume_reimbursement_points_text') : '',
    ];
    $form['volume_calculator']['volume_reimbursement_points_right_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical fee points select label'),
      '#description' => $this->t('Enter the Medical fee points select label'),
      '#default_value' => $config->get('volume_reimbursement_points_right_text') !== null ? $config->get('volume_reimbursement_points_right_text') : '',
    ];
    $form['volume_calculator']['volume_daily_average_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Daily average trading volume label'),
      '#description' => $this->t('Enter the Daily average trading volume label'),
      '#default_value' => $config->get('volume_daily_average_text') !== null ? $config->get('volume_daily_average_text') : '',
    ];
    $form['volume_calculator']['volume_room_preparation_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Room preparation and cleaning fee label'),
      '#description' => $this->t('Enter the Room preparation and cleaning fee label'),
      '#default_value' => $config->get('volume_room_preparation_text') !== null ? $config->get('volume_room_preparation_text') : '',
    ];
    $form['volume_calculator']['volume_room_preparation_select_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Room preparation and cleaning fee select label'),
      '#description' => $this->t('Enter the Room preparation and cleaning fee select label'),
      '#default_value' => $config->get('volume_room_preparation_select_text') !== null ? $config->get('volume_room_preparation_select_text') : ''
    ];
    $form['volume_calculator']['volume_initial_investment_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Initial Investment label'),
      '#description' => $this->t('Enter the Initial Investment label'),
      '#default_value' => $config->get('volume_initial_investment_text') !== null ? $config->get('volume_initial_investment_text') : '',
    ];
    $form['volume_calculator']['volume_initial_investment_select_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Initial Investment select label'),
      '#description' => $this->t('Enter the Initial Investment select label'),
      '#default_value' => $config->get('volume_initial_investment_select_text') !== null ? $config->get('volume_initial_investment_select_text') : ''
    ];
    // Simulation results section.
    $form['volume_calculator']['simulation_results_description'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Simulation results description text'),
      '#description' => $this->t('Enter the Simulation results description text'),
      '#default_value' => $config->get('simulation_results_description') !== null ? $config->get('simulation_results_description') : '',
    ];
    $form['volume_calculator']['initial_investment_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Initial Investment label'),
      '#description' => $this->t('Enter the initial investment amount label for simulation result'),
      '#default_value' => $config->get('initial_investment_label') !== null ? $config->get('initial_investment_label') : '',
    ];
    $form['volume_calculator']['medical_fee_per_hospitalization_label'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical Fee per Hospitalization label'),
      '#description' => $this->t('Enter the Medical Fee per Hospitalization label'),
      '#default_value' => $config->get('medical_fee_per_hospitalization_label') !== null ? $config->get('medical_fee_per_hospitalization_label') : '',
    ];
    $form['volume_calculator']['medical_fee_per_case_label'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical Fee per Case label'),
      '#description' => $this->t('Enter the Medical Fee per Case label'),
      '#default_value' => $config->get('medical_fee_per_case_label') !== null ? $config->get('medical_fee_per_case_label') : '',
    ];
    $form['volume_calculator']['investment_cost_per_case_label'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Initial Investment Cost ÷ (Medical Fee per Case) label'),
      '#description' => $this->t('Enter the Initial Investment Cost ÷ (Medical Fee per Case) label'),
      '#default_value' => $config->get('investment_cost_per_case_label') !== null ? $config->get('investment_cost_per_case_label') : '',
    ];
    $form['volume_calculator']['yen_conversion_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Yen conversion text'),
      '#description' => $this->t('Enter the Yen conversion text'),
      '#default_value' => $config->get('yen_conversion_text') !== null ? $config->get('yen_conversion_text') : '',
    ];
    // Pluvicto Volume Calculator field group.
    $form['pluvicto_volume_calculator'] = [
      '#type' => 'details',
      '#title' => $this->t('Pluvicto Calculator labels'),
      '#open' => FALSE,
    ];
    $form['pluvicto_volume_calculator']['pluvicto_calculator_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Pluvicto calculator title'),
      '#description' => $this->t('Enter the Pluvicto calculator title'),
      '#default_value' => $config->get('pluvicto_calculator_title') !== null ? $config->get('pluvicto_calculator_title') : ''
    ];
    // Calculator section.
    $form['pluvicto_volume_calculator']['pluvicto_hospitalization_period_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Hospitalization period after Pluvicto treatment label'),
      '#description' => $this->t('Enter the Hospitalization period after Pluvicto treatment label'),
      '#default_value' => $config->get('pluvicto_hospitalization_period_text') !== null ? $config->get('pluvicto_hospitalization_period_text') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_hosp_period_days_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Hospitalization period after Pluvicto treatment select label'),
      '#description' => $this->t('Enter the Hospitalization period after Pluvicto treatment select label'),
      '#default_value' => $config->get('pluvicto_hosp_period_days_text') !== null ? $config->get('pluvicto_hosp_period_days_text') : ''
    ];
    $form['pluvicto_volume_calculator']['pluvicto_reimbursement_points_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Reimbursement Points label'),
      '#description' => $this->t('Enter the Reimbursement Points label'),
      '#default_value' => $config->get('pluvicto_reimbursement_points_text') !== null ? $config->get('pluvicto_reimbursement_points_text') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_reimbursement_points_right_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Reimbursement Points value text'),
      '#description' => $this->t('Enter the Reimbursement Points value text'),
      '#default_value' => $config->get('pluvicto_reimbursement_points_right_text') !== null ? $config->get('pluvicto_reimbursement_points_right_text') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_daily_average_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Daily Average Fee-for-Service label'),
      '#description' => $this->t('Enter the Daily Average Fee-for-Service label'),
      '#default_value' => $config->get('pluvicto_daily_average_text') !== null ? $config->get('pluvicto_daily_average_text') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_room_preparation_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Room Preparation and Cleaning Costs label'),
      '#description' => $this->t('Enter the Room Preparation and Cleaning Costs label'),
      '#default_value' => $config->get('pluvicto_room_preparation_text') !== null ? $config->get('pluvicto_room_preparation_text') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_room_preparation_select_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Room Preparation and Cleaning Costs select label'),
      '#description' => $this->t('Enter the Room Preparation and Cleaning Costs select label'),
      '#default_value' => $config->get('pluvicto_room_preparation_select_text') !== null ? $config->get('pluvicto_room_preparation_select_text') : ''
    ];
    $form['pluvicto_volume_calculator']['pluvicto_initial_investment_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Initial Investment label'),
      '#description' => $this->t('Enter the Initial Investment label'),
      '#default_value' => $config->get('pluvicto_initial_investment_text') !== null ? $config->get('pluvicto_initial_investment_text') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_initial_investment_select_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Initial Investment select label'),
      '#description' => $this->t('Enter the Initial Investment select label'),
      '#default_value' => $config->get('pluvicto_initial_investment_select_text') !== null ? $config->get('pluvicto_initial_investment_select_text') : ''
    ];
    // Simulation results section.
    $form['pluvicto_volume_calculator']['pluvicto_simulation_results_description'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Simulation results description text'),
      '#description' => $this->t('Enter the Simulation results description text'),
      '#default_value' => $config->get('pluvicto_simulation_results_description') !== null ? $config->get('pluvicto_simulation_results_description') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_initial_investment_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Initial Investment label'),
      '#description' => $this->t('Enter the initial investment label for simulation result'),
      '#default_value' => $config->get('pluvicto_initial_investment_label') !== null ? $config->get('pluvicto_initial_investment_label') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_medical_fee_per_hospitalization_label'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical Fee per Hospitalization label'),
      '#description' => $this->t('Enter the Medical Fee per Hospitalization label'),
      '#default_value' => $config->get('pluvicto_medical_fee_per_hospitalization_label') !== null ? $config->get('pluvicto_medical_fee_per_hospitalization_label') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_medical_fee_per_case_label'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical Fee per Case label'),
      '#description' => $this->t('Enter the Medical Fee per Case label'),
      '#default_value' => $config->get('pluvicto_medical_fee_per_case_label') !== null ? $config->get('pluvicto_medical_fee_per_case_label') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_investment_cost_per_case_label'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Initial Investment Cost ÷ (Medical Fee per Case) label'),
      '#description' => $this->t('Enter the Initial Investment Cost ÷ (Medical Fee per Case) label'),
      '#default_value' => $config->get('pluvicto_investment_cost_per_case_label') !== null ? $config->get('pluvicto_investment_cost_per_case_label') : '',
    ];
    $form['pluvicto_volume_calculator']['pluvicto_yen_conversion_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Yen conversion text'),
      '#description' => $this->t('Enter the Yen conversion text'),
      '#default_value' => $config->get('pluvicto_yen_conversion_text') !== null ? $config->get('pluvicto_yen_conversion_text') : '',
    ];
    // DPC Calculator field group.
    $form['dpc_calculator'] = [
      '#type' => 'details',
      '#title' => $this->t('DPC Calculator labels'),
      '#open' => FALSE,
    ];
    $form['dpc_calculator']['dpc_calculator_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('DPC calculator title'),
      '#description' => $this->t('Enter the calculator title'),
      '#default_value' => $config->get('dpc_calculator_title') !== null ? $config->get('dpc_calculator_title') : ''
    ];
    // Calculator section.
    $form['dpc_calculator']['dpc_hospitalization_period_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Length of hospital stay after Lutathera treatment label'),
      '#description' => $this->t('Enter the Length of hospital stay after Lutathera treatment label'),
      '#default_value' => $config->get('dpc_hospitalization_period_text') !== null ? $config->get('dpc_hospitalization_period_text') : '',
    ];
    $form['dpc_calculator']['dpc_hosp_period_days_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Length of hospital stay after Lutathera treatment select label'),
      '#description' => $this->t('Enter the Length of hospital stay after Lutathera treatment select label'),
      '#default_value' => $config->get('dpc_hosp_period_days_text') !== null ? $config->get('dpc_hosp_period_days_text') : ''
    ];
    $form['dpc_calculator']['dpc_reimbursement_points_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical fee points label'),
      '#description' => $this->t('Enter the Medical fee points label'),
      '#default_value' => $config->get('dpc_reimbursement_points_text') !== null ? $config->get('dpc_reimbursement_points_text') : '',
    ];
    $form['dpc_calculator']['dpc_reimbursement_points_right_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical fee points select label'),
      '#description' => $this->t('Enter the Medical fee points select label'),
      '#default_value' => $config->get('dpc_reimbursement_points_right_text') !== null ? $config->get('dpc_reimbursement_points_right_text') : '',
    ];
    $form['dpc_calculator']['dpc_room_preparation_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Room preparation and cleaning fee label'),
      '#description' => $this->t('Enter the Room preparation and cleaning fee label'),
      '#default_value' => $config->get('dpc_room_preparation_text') !== null ? $config->get('dpc_room_preparation_text') : '',
    ];
    $form['dpc_calculator']['dpc_room_preparation_select_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Room preparation and cleaning fee select label'),
      '#description' => $this->t('Enter the Room preparation and cleaning fee select label'),
      '#default_value' => $config->get('dpc_room_preparation_select_text') !== null ? $config->get('dpc_room_preparation_select_text') : ''
    ];
    $form['dpc_calculator']['dpc_initial_investment_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Initial Investment label'),
      '#description' => $this->t('Enter the Initial Investment label'),
      '#default_value' => $config->get('dpc_initial_investment_text') !== null ? $config->get('dpc_initial_investment_text') : '',
    ];
    $form['dpc_calculator']['dpc_initial_investment_select_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Initial Investment select label'),
      '#description' => $this->t('Enter the Initial Investment select label'),
      '#default_value' => $config->get('dpc_initial_investment_select_text') !== null ? $config->get('dpc_initial_investment_select_text') : ''
    ];
    $form['dpc_calculator']['dpc_others_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Others label'),
      '#description' => $this->t('Enter the Others label'),
      '#default_value' => $config->get('dpc_others_label') !== null ? $config->get('dpc_others_label') : ''
    ];
    $form['dpc_calculator']['dpc_coefficients_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Coefficients by Medical Institution label'),
      '#description' => $this->t('Enter the Coefficients by Medical Institution label'),
      '#default_value' => $config->get('dpc_coefficients_text') !== null ? $config->get('dpc_coefficients_text') : '',
    ];
    $form['dpc_calculator']['dpc_coefficients_select_text'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Coefficients by Medical Institution select label'),
      '#description' => $this->t('Enter the Coefficients by Medical Institution select label'),
      '#default_value' => $config->get('dpc_coefficients_select_text') !== null ? $config->get('dpc_coefficients_select_text') : ''
    ];
    // Simulation results section.
    $form['dpc_calculator']['dpc_simulation_results_description'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Simulation results description text'),
      '#description' => $this->t('Enter the Simulation results description text'),
      '#default_value' => $config->get('dpc_simulation_results_description') !== null ? $config->get('dpc_simulation_results_description') : '',
    ];
    $form['dpc_calculator']['dpc_initial_investment_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Initial Investment label'),
      '#description' => $this->t('Enter the initial investment amount label for simulation results'),
      '#default_value' => $config->get('dpc_initial_investment_label') !== null ? $config->get('dpc_initial_investment_label') : ''
    ];
    $form['dpc_calculator']['dpc_medical_fee_per_hospitalization_label'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical Fee per Hospitalization label'),
      '#description' => $this->t('Enter the Medical Fee per Hospitalization label'),
      '#default_value' => $config->get('dpc_medical_fee_per_hospitalization_label') !== null ? $config->get('dpc_medical_fee_per_hospitalization_label') : '',
    ];
    $form['dpc_calculator']['dpc_medical_fee_per_case_label'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Medical Fee per Case label'),
      '#description' => $this->t('Enter the Medical Fee per Case label'),
      '#default_value' => $config->get('dpc_medical_fee_per_case_label') !== null ? $config->get('dpc_medical_fee_per_case_label') : '',
    ];
    $form['dpc_calculator']['dpc_investment_cost_per_case_label'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Initial Investment Cost ÷ (Medical Fee per Case) label'),
      '#description' => $this->t('Enter the Initial Investment Cost ÷ (Medical Fee per Case) label'),
      '#default_value' => $config->get('dpc_investment_cost_per_case_label') !== null ? $config->get('dpc_investment_cost_per_case_label') : '',
    ];
    $form['dpc_calculator']['dpc_yen_conversion_text'] = [
      '#type' => 'text_format',
      '#format' => 'rich_text',
      '#title' => $this->t('Yen conversion text'),
      '#description' => $this->t('Enter the Yen conversion text'),
      '#default_value' => $config->get('dpc_yen_conversion_text') !== null ? $config->get('dpc_yen_conversion_text') : '',
    ];
    // DPC Calculator Cost Settings field group.
    $form['dpc_calculator']['dpc_cost_settings'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('DPC Calculator Cost Settings'),
      '#collapsible' => TRUE,
      '#collapsed' => FALSE,
    ];
    $form['dpc_calculator']['dpc_cost_settings']['lutaterra_cost'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Lutaterra cost'),
      '#description' => $this->t('Lutaterra cost in Yen'),
      '#default_value' => $config->get('lutaterra_cost') !== null ? $config->get('lutaterra_cost') : '',
      '#element_validate' => [
      [$this, 'validateNumericField'],
      ],
    ];
    $form['dpc_calculator']['dpc_cost_settings']['liza_care_cost'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Liza cost'),
      '#description' => $this->t('Liza cost in Yen'),
      '#default_value' => $config->get('liza_care_cost') !== null ? $config->get('liza_care_cost') : '',
      '#element_validate' => [
      [$this, 'validateNumericField'],
      ],
    ];
    $form['dpc_calculator']['dpc_cost_settings']['granisetron_cost'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Granisetron cost'),
      '#description' => $this->t('Granisetron cost in Yen'),
      '#default_value' => $config->get('granisetron_cost') !== null ? $config->get('granisetron_cost') : '',
      '#element_validate' => [
      [$this, 'validateNumericField'],
      ],
    ];

    return parent::buildForm($form, $form_state);

  }

  /**
   * Validation callback for numeric fields.
   */
  public function validateNumericField(array &$element, FormStateInterface $form_state, array &$complete_form) {
    if (!is_numeric($element['#value'])) {
      $form_state->setError($element, $this->t('The value must be a numeric value.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);
    $this->config('rlt_volume_calculator_items.dpc_settings')
      ->set('simulation_results_label', $form_state->getValue('simulation_results_label'))
      ->set('simulation_results_download_label', $form_state->getValue('simulation_results_download_label'))
      ->set('income_title', $form_state->getValue('income_title'))
      ->set('expenses_title', $form_state->getValue('expenses_title'))
      ->set('items_required_description', $form_state->getValue('items_required_description'))
      ->set('run_simulation_text', $form_state->getValue('run_simulation_text'))
      ->set('classification_label', $form_state->getValue('classification_label'))
      ->set('item_label', $form_state->getValue('item_label'))
      ->set('score_label', $form_state->getValue('score_label'))
      ->set('addition_method_label', $form_state->getValue('addition_method_label'))
      ->set('hospitalization_period_points_label', $form_state->getValue('hospitalization_period_points_label'))
      ->set('remarks_label', $form_state->getValue('remarks_label'))
      ->set('lutaterra_cost', $form_state->getValue('lutaterra_cost'))
      ->set('liza_care_cost', $form_state->getValue('liza_care_cost'))
      ->set('granisetron_cost', $form_state->getValue('granisetron_cost'))
      ->set('volume_calculator_title', $form_state->getValue('volume_calculator_title'))
      ->set('volume_hospitalization_period_text', $form_state->getValue(['volume_hospitalization_period_text', 'value']))
      ->set('volume_hospitalization_period_text_format', $form_state->getValue(['volume_hospitalization_period_text', 'format']))
      ->set('volume_hosp_period_days_text', $form_state->getValue('volume_hosp_period_days_text'))
      ->set('volume_reimbursement_points_text', $form_state->getValue(['volume_reimbursement_points_text', 'value']))
      ->set('volume_reimbursement_points_text_format', $form_state->getValue(['volume_reimbursement_points_text', 'format']))
      ->set('volume_reimbursement_points_right_text', $form_state->getValue(['volume_reimbursement_points_right_text', 'value']))
      ->set('volume_reimbursement_points_right_text_format', $form_state->getValue(['volume_reimbursement_points_right_text', 'format']))
      ->set('volume_daily_average_text', $form_state->getValue(['volume_daily_average_text', 'value']))
      ->set('volume_daily_average_text_format', $form_state->getValue(['volume_daily_average_text', 'format']))
      ->set('volume_room_preparation_text', $form_state->getValue(['volume_room_preparation_text', 'value']))
      ->set('volume_room_preparation_text_format', $form_state->getValue(['volume_room_preparation_text', 'format']))
      ->set('volume_room_preparation_select_text', $form_state->getValue('volume_room_preparation_select_text'))
      ->set('volume_initial_investment_text', $form_state->getValue(['volume_initial_investment_text', 'value']))
      ->set('volume_initial_investment_text_format', $form_state->getValue(['volume_initial_investment_text', 'format']))
      ->set('volume_initial_investment_select_text', $form_state->getValue('volume_initial_investment_select_text'))
      ->set('initial_investment_label', $form_state->getValue('initial_investment_label'))
      ->set('simulation_results_description', $form_state->getValue(['simulation_results_description', 'value']))
      ->set('simulation_results_description_format', $form_state->getValue(['simulation_results_description', 'format']))
      ->set('medical_fee_per_hospitalization_label', $form_state->getValue(['medical_fee_per_hospitalization_label', 'value']))
      ->set('medical_fee_per_hospitalization_label_format', $form_state->getValue(['medical_fee_per_hospitalization_label', 'format']))
      ->set('medical_fee_per_case_label', $form_state->getValue(['medical_fee_per_case_label', 'value']))
      ->set('medical_fee_per_case_label_format', $form_state->getValue(['medical_fee_per_case_label', 'format']))
      ->set('investment_cost_per_case_label', $form_state->getValue(['investment_cost_per_case_label', 'value']))
      ->set('investment_cost_per_case_label_format', $form_state->getValue(['investment_cost_per_case_label', 'format']))
      ->set('yen_conversion_text', $form_state->getValue(['yen_conversion_text', 'value']))
      ->set('yen_conversion_text_format', $form_state->getValue(['yen_conversion_text', 'format']))
      ->set('dpc_calculator_title', $form_state->getValue('dpc_calculator_title'))
      ->set('dpc_others_label', $form_state->getValue('dpc_others_label'))
      ->set('dpc_hospitalization_period_text', $form_state->getValue(['dpc_hospitalization_period_text', 'value']))
      ->set('dpc_hospitalization_period_text_format', $form_state->getValue(['dpc_hospitalization_period_text', 'format']))
      ->set('dpc_hosp_period_days_text', $form_state->getValue('dpc_hosp_period_days_text'))
      ->set('dpc_reimbursement_points_text', $form_state->getValue(['dpc_reimbursement_points_text', 'value']))
      ->set('dpc_reimbursement_points_text_format', $form_state->getValue(['dpc_reimbursement_points_text', 'format']))
      ->set('dpc_reimbursement_points_right_text', $form_state->getValue(['dpc_reimbursement_points_right_text', 'value']))
      ->set('dpc_reimbursement_points_right_text_format', $form_state->getValue(['dpc_reimbursement_points_right_text', 'format']))
      ->set('dpc_room_preparation_text', $form_state->getValue(['dpc_room_preparation_text', 'value']))
      ->set('dpc_room_preparation_text_format', $form_state->getValue(['dpc_room_preparation_text', 'format']))
      ->set('dpc_room_preparation_select_text', $form_state->getValue('dpc_room_preparation_select_text'))
      ->set('dpc_initial_investment_text', $form_state->getValue(['dpc_initial_investment_text', 'value']))
      ->set('dpc_initial_investment_text_format', $form_state->getValue(['dpc_initial_investment_text', 'format']))
      ->set('dpc_initial_investment_select_text', $form_state->getValue('dpc_initial_investment_select_text'))
      ->set('dpc_coefficients_text', $form_state->getValue(['dpc_coefficients_text', 'value']))
      ->set('dpc_coefficients_text_format', $form_state->getValue(['dpc_coefficients_text', 'format']))
      ->set('dpc_coefficients_select_text', $form_state->getValue('dpc_coefficients_select_text'))
      ->set('dpc_simulation_results_description', $form_state->getValue(['dpc_simulation_results_description', 'value']))
      ->set('dpc_simulation_results_description_format', $form_state->getValue(['dpc_simulation_results_description', 'format']))
      ->set('dpc_initial_investment_label', $form_state->getValue('dpc_initial_investment_label'))
      ->set('dpc_medical_fee_per_hospitalization_label', $form_state->getValue(['dpc_medical_fee_per_hospitalization_label', 'value']))
      ->set('dpc_medical_fee_per_hospitalization_label_format', $form_state->getValue(['dpc_medical_fee_per_hospitalization_label', 'format']))
      ->set('dpc_medical_fee_per_case_label', $form_state->getValue(['dpc_medical_fee_per_case_label', 'value']))
      ->set('dpc_medical_fee_per_case_label_format', $form_state->getValue(['dpc_medical_fee_per_case_label', 'format']))
      ->set('dpc_investment_cost_per_case_label', $form_state->getValue(['dpc_investment_cost_per_case_label', 'value']))
      ->set('dpc_investment_cost_per_case_label_format', $form_state->getValue(['dpc_investment_cost_per_case_label', 'format']))
      ->set('dpc_yen_conversion_text', $form_state->getValue(['dpc_yen_conversion_text', 'value']))
      ->set('dpc_yen_conversion_text_format', $form_state->getValue(['dpc_yen_conversion_text', 'format']))
      ->set('pluvicto_calculator_title', $form_state->getValue('pluvicto_calculator_title'))
      ->set('pluvicto_hospitalization_period_text', $form_state->getValue(['pluvicto_hospitalization_period_text', 'value']))
      ->set('pluvicto_hospitalization_period_text_format', $form_state->getValue(['pluvicto_hospitalization_period_text', 'format']))
      ->set('pluvicto_hosp_period_days_text', $form_state->getValue('pluvicto_hosp_period_days_text'))
      ->set('pluvicto_reimbursement_points_text', $form_state->getValue(['pluvicto_reimbursement_points_text', 'value']))
      ->set('pluvicto_reimbursement_points_text_format', $form_state->getValue(['pluvicto_reimbursement_points_text', 'format']))
      ->set('pluvicto_reimbursement_points_right_text', $form_state->getValue(['pluvicto_reimbursement_points_right_text', 'value']))
      ->set('pluvicto_reimbursement_points_right_text_format', $form_state->getValue(['pluvicto_reimbursement_points_right_text', 'format']))
      ->set('pluvicto_daily_average_text', $form_state->getValue(['pluvicto_daily_average_text', 'value']))
      ->set('pluvicto_daily_average_text_format', $form_state->getValue(['pluvicto_daily_average_text', 'format']))
      ->set('pluvicto_room_preparation_text', $form_state->getValue(['pluvicto_room_preparation_text', 'value']))
      ->set('pluvicto_room_preparation_text_format', $form_state->getValue(['pluvicto_room_preparation_text', 'format']))
      ->set('pluvicto_room_preparation_select_text', $form_state->getValue('pluvicto_room_preparation_select_text'))
      ->set('pluvicto_initial_investment_text', $form_state->getValue(['pluvicto_initial_investment_text', 'value']))
      ->set('pluvicto_initial_investment_text_format', $form_state->getValue(['pluvicto_initial_investment_text', 'format']))
      ->set('pluvicto_initial_investment_select_text', $form_state->getValue('pluvicto_initial_investment_select_text'))
      ->set('pluvicto_initial_investment_label', $form_state->getValue('pluvicto_initial_investment_label'))
      ->set('pluvicto_simulation_results_description', $form_state->getValue(['pluvicto_simulation_results_description', 'value']))
      ->set('pluvicto_simulation_results_description_format', $form_state->getValue(['pluvicto_simulation_results_description', 'format']))
      ->set('pluvicto_medical_fee_per_hospitalization_label', $form_state->getValue(['pluvicto_medical_fee_per_hospitalization_label', 'value']))
      ->set('pluvicto_medical_fee_per_hospitalization_label_format', $form_state->getValue(['pluvicto_medical_fee_per_hospitalization_label', 'format']))
      ->set('pluvicto_medical_fee_per_case_label', $form_state->getValue(['pluvicto_medical_fee_per_case_label', 'value']))
      ->set('pluvicto_medical_fee_per_case_label_format', $form_state->getValue(['pluvicto_medical_fee_per_case_label', 'format']))
      ->set('pluvicto_investment_cost_per_case_label', $form_state->getValue(['pluvicto_investment_cost_per_case_label', 'value']))
      ->set('pluvicto_investment_cost_per_case_label_format', $form_state->getValue(['pluvicto_investment_cost_per_case_label', 'format']))
      ->set('pluvicto_yen_conversion_text', $form_state->getValue(['pluvicto_yen_conversion_text', 'value']))
      ->set('pluvicto_yen_conversion_text_format', $form_state->getValue(['pluvicto_yen_conversion_text', 'format']))
      ->save();
  }
  

}
