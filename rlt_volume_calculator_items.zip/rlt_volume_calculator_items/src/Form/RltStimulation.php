<?php

namespace Drupal\rlt_volume_calculator_items\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * {@inheritdoc}
 */
class RltStimulation extends FormBase {

  /**
   * The configuration factory service.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Constructs a new RltStimulation object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   */
  public function __construct(ConfigFactoryInterface $config_factory) {
    $this->configFactory = $config_factory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'rlt_stimulation';
  }

  /**
   * Build the custom form.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   The built form.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->configFactory->get('rlt_volume_calculator_items.dpc_settings');
    $simulation_results_label = $config->get('simulation_results_label') != null ? $this->t($config->get('simulation_results_label')) : $this->t('Simulation results');
    $simulation_results_download_label = $config->get('simulation_results_download_label') != null ? $this->t($config->get('simulation_results_download_label')) : $this->t('Download full results');
    // Simulation results labels.
    $simulation_results_description = $config->get('simulation_results_description') != null ? $this->t($config->get('simulation_results_description')) : '<p>' . $this->t('The estimated number of Lutathera treatment patients needed to cover the initial investment is <span class="no-of-people">21</span> or more.<br>(The recommended number of doses is <span class="no-of-doses">81</span> or more times.)') . '</p>';
    $initial_investment_label = $config->get('initial_investment_label') != null ? $this->t($config->get('initial_investment_label')) : $this->t('Initial investment');
    $medical_fee_per_hospitalization_label = $config->get('medical_fee_per_hospitalization_label') != null ? $this->t($config->get('medical_fee_per_hospitalization_label')) : $this->t('Medical fee per hospitalization (per administration)***');
    $medical_fee_per_case_label = $config->get('medical_fee_per_case_label') != null ? $this->t($config->get('medical_fee_per_case_label')) : $this->t('Medical fee per case (4 doses) ***');
    $investment_cost_per_case_label = $config->get('investment_cost_per_case_label') != null ? $this->t($config->get('investment_cost_per_case_label')) : $this->t('Initial investment cost ÷ (medical fee per case)***');
    $yen_conversion_text = $config->get('yen_conversion_text') != null ? $this->t($config->get('yen_conversion_text')) : $this->t('*** Yen conversion');
    // Simulation items labels.
    $classification_label = $config->get('classification_label') != null ? $this->t($config->get('classification_label')) : $this->t('Classification');
    $item_label = $config->get('item_label') != null ? $this->t($config->get('item_label')) : $this->t('Item');
    $score_label = $config->get('score_label') != null ? $this->t($config->get('score_label')) : $this->t('Score');
    $addition_method_label = $config->get('addition_method_label') != null ? $this->t($config->get('addition_method_label')) : $this->t('Addition method Kasan');
    $hospitalization_period_points_label = $config->get('hospitalization_period_points_label') != null ? $this->t($config->get('hospitalization_period_points_label')) : $this->t('Hospitalization Period Points');
    $remarks_label = $config->get('remarks_label') != null ? $this->t($config->get('remarks_label')) : $this->t('Remarks');
    
    $form['simulation_results'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['medical-fee-calculator', 'output','volume-simulation']],
    ];

    $form['simulation_results']['header'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['simulation-result-header volume-calculator-header']],
    ];

    $form['simulation_results']['header']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => '<h3 class="strong">' . $simulation_results_label . '</h3>' .
        $simulation_results_description,
      ],
    ];

    $form['simulation_results']['header']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part']],
      'content' => [
        '#markup' => '<a href="#" id="stimulation-results" class="btn border-curved btn-big btn-secondary">' . $simulation_results_download_label . '</a>',
      ],
    ];

    $form['simulation_results']['body'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['simulation-result-body volume-calculator-results']],
    ];

    $form['simulation_results']['body']['initial_investment'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-header-row'], 'id' => ['result-initial-investment']],
      'content' => [
        '#markup' => '<div class="left-part">' . $initial_investment_label . '</div>' .
        '<div class="right-part">5,000,000 ' . $this->t('yen') . '</div>',
      ],
    ];

    $form['simulation_results']['body']['fee_details'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['fee-details']],
    ];

    $fee_blocks = [
      [
        'header' => $medical_fee_per_hospitalization_label,
        'body' => '61,870 yen',
      ],
      [
        'header' => $medical_fee_per_case_label,
        'body' => '247,480 yen',
      ],
      [
        'header' => $investment_cost_per_case_label,
        'body' => '21 people',
      ],
    ];

    foreach ($fee_blocks as $index => $block) {
      $form['simulation_results']['body']['fee_details']['fee_block_' . $index] = [
        '#type' => 'container',
        '#attributes' => ['class' => ['fee-block']],
        'header' => [
          '#type' => 'container',
          '#attributes' => ['class' => ['fee-block-header']],
          'content' => [
            '#markup' => $block['header'],
          ],
        ],
        'body' => [
          '#type' => 'container',
          '#attributes' => ['class' => ['fee-block-body'], 'id' => ['fee-block-' . $index]],
          'content' => [
            '#markup' => '<h4 class="fee-block-value">' . $block['body'] . '</h4>',
          ],
        ],
      ];
    }

    $form['simulation_results']['body']['footer'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-footer-row']],
      'content' => [
        '#markup' => $yen_conversion_text,
      ],
    ];

    $rows = '';
    $items = $this->getCalculationItems();

    if(!empty($items)) {
      $form['simulation_results']['table'] = [
        '#type' => 'container',
        '#attributes' => ['class' => ['simulation-result-table']],
      ];
  
      $form['simulation_results']['table']['header'] = [
        '#type' => 'markup',
        '#markup' => '<h4 class="strong">' . $this->t('Items calculated in the simulation') . '</h4>',
      ];
  
      $form['simulation_results']['table']['table'] = [
        '#type' => 'markup',
        '#markup' => '<div class="calculated-table"><div class="responsiveDiv volume-calculator-items"><div><table>
        <thead>
          <tr>
          <th>' . $classification_label . '</th>
          <th>' . $item_label . '</th>
          <th>' . $score_label . '</th>
          <th class="addition-method">' . $addition_method_label . '</th>
          <th>' . $hospitalization_period_points_label . '</th>
          <th>' . $remarks_label . '</th>
          </tr>
        </thead>',
      ];
      
      foreach ($items as $item) {
        $addition_method = $item['addition_method'][0]['value'] ?? 'D';
        $method = $this->getTaxonomyTermsByVid('addition_method', $addition_method);
        $classification = !empty($item['classification']) ? $item['classification'][0]['value'] : '';
        $item_val = !empty($item['item']) ? $item['item'][0]['value'] : '';
        $score = !empty($item['score']) ? $item['score'][0]['value'] : '';
        $remarks = !empty($item['remarks']) ? $item['remarks'][0]['value'] : '';
        $rows .= '<tr>
        <td>' . $classification . '</td>
        <td>' . $item_val . '</td>
        <td class="items-score">' . $score . '</td>
        <td class="addition-method">' . (is_array($method) ? implode(', ', $method) : $method) . '</td>
        <td class="items-hosp-period-points">' . $score . '</td>
        <td>' . $remarks . '</td>
        </tr>';
      }
  
      $form['simulation_results']['table']['table_body'] = [
        '#type' => 'markup',
        '#markup' => '<tbody>' . $rows . '</tbody>
        </table></div></div></div>',
      ];
  
      $form['simulation_results']['table']['footer'] = [
        '#type' => 'container',
        '#attributes' => ['class' => ['form-action']],
        'content' => [
          '#type' => 'markup',
          '#markup' => '<a id="toggle-table" class="table-expand btn form-control">' . $this->t('View full items') . '</a>',
        ],
      ];
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * Get Calculation Items.
   *
   * @return array
   *   An array of Calculation Items.
   */
  public function getCalculationItems() {
    $storage = \Drupal::entityTypeManager()->getStorage('rlt_volume_calculator_items');
    $entities = $storage->loadMultiple();

    $items = [];
    foreach ($entities as $entity) {
      if(!empty($entity->get('type')->getValue()) && $entity->get('type')->getValue()[0]['value'] == 'volume') {
        $items[] = $entity->toArray();
      }
    }

    return $items;
  }

  /**
   * Get all taxonomy terms by vocabulary ID.
   *
   * @param string $vid
   *   The vocabulary ID.
   *
   * @return array
   *   An array of taxonomy terms.
   */
  public function getTaxonomyTermsByVid($vid, $tid = NULL) {
    $storage = \Drupal::entityTypeManager()->getStorage('taxonomy_term');
    // If a specific term ID is provided, return its name if published.
    if ($tid) {
      return $this->getSingleTermName($storage, $tid);
    }
    // Otherwise, return all published terms for the vocabulary.
    return $this->getPublishedTermsList($storage, $vid);
  }

  /**
   * Get a single term name if published.
   */
  private function getSingleTermName($storage, $tid) {
    $term = $storage->load($tid);
    return ($term && $term->isPublished()) ? $term->getName() : [];
  }

  /**
   * Get all published terms for a vocabulary.
   */
  private function getPublishedTermsList($storage, $vid) {
    $terms = $storage->loadTree($vid);
    $term_list = [];
    foreach ($terms as $term) {
      if ($term->status == "1") {
        $term_list[$term->name] = $term->name;
      }
    }
    return $term_list;
  }

}
