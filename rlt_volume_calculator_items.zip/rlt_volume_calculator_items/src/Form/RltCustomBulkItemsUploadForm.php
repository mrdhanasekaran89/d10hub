<?php

namespace Drupal\rlt_volume_calculator_items\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class RltCustomBulkItemsUploadForm.
 */
class RltCustomBulkItemsUploadForm extends ConfigFormBase {
  public $file;

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'rlt_volume_calculator_items.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'rlt_volume_calculator_items_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildForm($form, $form_state);
    $form['file'] = [
      '#type' => 'file',
      '#title' => 'CSV file upload',
      '#upload_validators' => [
        'file_validate_extensions' => ['csv'],
      ],
      '#description' => $this->t('Upload a CSV file. Only .csv files are allowed.'),
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Import items'),
      '#button_type' => 'primary',
    ];

    return $form;

  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
    // Validate file.
    $file = file_save_upload('file', $form['file']['#upload_validators'], FALSE, 0);
    if (!$file) {
      $form_state->setErrorByName('file', $this->t('No file chosen or invalid file type.'));
    }
    else {
      $this->file = $file;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Open the uploaded file.
    // Get form data.
    $file = $this->file;

    // Batch process definition.
    $batch = [
      'title' => $this->t('Importing items...'),
      'operations' => [],
      'finished' => [$this, 'batchFinished'],
    ];

    // Open the file and read the data.
    $handle = fopen($file->getFileUri(), 'r');
    $sepchar = ',';
    $i = 0;

    while ($row = fgetcsv($handle, 0, $sepchar)) {
      if ($i > 0) {
        $batch['operations'][] = [[$this, 'processItems'], [$row]];
      }
      $i++;
    }

    // Close the file.
    fclose($handle);

    // Set the batch.
    batch_set($batch);
  }

  /**
   * Batch operation callback to process a single item.
   */
  public function processItems($row, &$context) {
    if(!empty($row[0])) {
      $itemsCsvData = prepareItemsData($row);
      uploadItemRecords($itemsCsvData);
    }
    // Track the progress.
    if (!isset($context['results']['processed'])) {
      $context['results']['processed'] = 0;
    }
    $context['results']['processed']++;
  }

  /**
   * Batch finished callback.
   */
  public function batchFinished($success, $results, $operations) {
    if ($success) {
      \Drupal::messenger()->addStatus($this->t('Successfully imported @count items.', ['@count' => $results['processed']]));
    }
    else {
      \Drupal::messenger()->addError($this->t('An error occurred during the import process.'));
    }
  }

}
