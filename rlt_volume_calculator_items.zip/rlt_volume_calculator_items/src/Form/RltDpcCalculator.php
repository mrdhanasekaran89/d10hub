<?php

namespace Drupal\rlt_volume_calculator_items\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\CssCommand;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\rlt_volume_calculator_items\Services\RltCalculatorServices;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * {@inheritdoc}
 */
class RltDpcCalculator extends FormBase {
  
  /**
   * The configuration factory service.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The RltCalculatorServices service.
   *
   * @var \Drupal\rlt_volume_calculator_items\Services\RltCalculatorServices
   */
  protected $calculatorService;

  /**
   * Constructs a new RltDpcCalculator object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\rlt_volume_calculator_items\Services\RltCalculatorServices $calculatorService
   *   The calculator service.
   */
  public function __construct(ConfigFactoryInterface $config_factory, RltCalculatorServices $calculatorService) {
    $this->configFactory = $config_factory;
    $this->calculatorService = $calculatorService;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('rlt_volume_calculator_items.calculator_services')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'rlt_dpc_calculator';
  }

  /**
   * Build the custom form.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   The built form.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->configFactory->get('rlt_volume_calculator_items.dpc_settings');
    // Calculator labels.
    $dpc_calculator_title = $config->get('dpc_calculator_title') != null ? $this->t($config->get('dpc_calculator_title')) : $this->t('DPC comprehensive');
    $volume_calculator_title = $config->get('volume_calculator_title') != null ? $this->t($config->get('volume_calculator_title')) : $this->t('Volume calculation');
    $income_title = $config->get('income_title') != null ? $this->t($config->get('income_title')) : $this->t('Income');
    $expenses_title = $config->get('expenses_title') != null ? $this->t($config->get('expenses_title')) : $this->t('Expenses');
    $run_simulation_text = $config->get('run_simulation_text') != null ? $this->t($config->get('run_simulation_text')) : $this->t('Run Simulation');
    $items_required_description = $config->get('items_required_description') != null ? $this->t($config->get('items_required_description')) : $this->t('**Major items required as initial investment');
    $dpc_hospitalization_period_text = $config->get('dpc_hospitalization_period_text') != null ? $this->t($config->get('dpc_hospitalization_period_text')) : $this->t('Length of hospital stay after Lutathera treatment');
    $dpc_hosp_period_days_text = $config->get('dpc_hosp_period_days_text') != null ? $this->t($config->get('dpc_hosp_period_days_text')) : $this->t('Days');
    $dpc_reimbursement_points_text = $config->get('dpc_reimbursement_points_text') != null ? $this->t($config->get('dpc_reimbursement_points_text')) : $this->t('Medical fee points') . '<br>' . $this->t('(comprehensive evaluation portion + fee-for service portion)');
    $dpc_room_preparation_text = $config->get('dpc_room_preparation_text') != null ? $this->t($config->get('dpc_room_preparation_text')) : $this->t('Room preparation and cleaning fee') . ' <span class="description">' . $this->t('Yen (per hospitalization)') . '</span>';
    $dpc_room_preparation_select_text = $config->get('dpc_room_preparation_select_text') != null ? $this->t($config->get('dpc_room_preparation_select_text')) : $this->t('Room Preparation and Cleaning Fee');
    $dpc_initial_investment_text = $config->get('dpc_initial_investment_text') != null ? $this->t($config->get('dpc_initial_investment_text')) : $this->t('Initial Investment**') . ' <span class="description">' . $this->t('Yen') . '</span>';
    $dpc_initial_investment_select_text = $config->get('dpc_initial_investment_select_text') != null ? $this->t($config->get('dpc_initial_investment_select_text')) : $this->t('Initial Investment');
    $dpc_others_label = $config->get('dpc_others_label') != null ? $this->t($config->get('dpc_others_label')) : $this->t('Others');
    $dpc_coefficients_text = $config->get('dpc_coefficients_text') != null ? $this->t($config->get('dpc_coefficients_text')) : $this->t('Coefficients by Medical Institution') . ' <span class="description">' . $this->t('Yen (per hospitalization)') . '</span>';
    $dpc_coefficients_select_text = $config->get('dpc_coefficients_select_text') != null ? $this->t($config->get('dpc_coefficients_select_text')) : $this->t('Coefficients');

    $form['#prefix'] = '<div class="content"><div class="medical-fee-calculator input dpc-calculation">';
    $form['#suffix'] = '</div></div>';

    $form['#attached']['html_head'][] = [
      [
        '#tag' => 'style',
        '#value' => '#block-rltdpcsimulationblock ,.download-pdf-wrapper { display: none; }',
      ],
      'hide-block-css',
    ];

    $form['volume_header'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-header']],
    ];

    $form['volume_header']['left'] = [
      '#type' => 'markup',
      '#markup' => '<h4 class="strong">' . $dpc_calculator_title . '</h4>',
    ];

    $form['volume_header']['right'] = [
      '#type' => 'select',
      '#options' => [
        'DPC comprehensive' => $dpc_calculator_title,
        'Volume calculation' => $volume_calculator_title,
      ],
      '#ajax' => [
        'callback' => '::hideBlockOnDpcChange',
        'event' => 'change',
        'wrapper' => 'ajax-wrapper-dpc',
      ],
      '#attributes' => ['class' => ['form-select']],
    ];

    $form['income_header'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-header-row']],
      'content' => [
        '#markup' => $income_title,
      ],
    ];
    $form['length_of_stay'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row', 'length-of-stay']],
    ];

    $form['length_of_stay']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => $dpc_hospitalization_period_text,
      ],
    ];
    $form['length_of_stay']['right_part'] = [
      '#type' => 'select',
      '#title' => $dpc_hosp_period_days_text,
      '#options' => $this->calculatorService->getTaxonomyTermsByVid('length_of_hospital_stay', NULL, 'dpc'),
      '#attributes' => ['class' => ['form-select', 'length-of-stay-select']],
      '#label_attributes' => ['class' => ['form-required']],
      '#ajax' => [
        'callback' => '::updateMedicalFeePoints',
        'event' => 'change',
        'wrapper' => 'ajax-wrapper-dpc',
      ],
    ];

    $form['ajax_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'ajax-wrapper-dpc'],
    ];

    $form['ajax_wrapper']['dpc_medical_fee_points'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row', 'field-data']],
    ];

    $form['ajax_wrapper']['dpc_medical_fee_points']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => $dpc_reimbursement_points_text,
      ],
    ];

    $form['ajax_wrapper']['dpc_medical_fee_points']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part'], 'id' => ['medical-fee-points']],
      '#markup' => '<div class="dpc-medical-fee-points-wrapper d-flex align-items-center gap-2"></div>',
    ];
    $form['ajax_wrapper']['daily_average_volume'] = [
      '#type' => 'container',
      '#attributes' => [
        'class' => ['table-body-row', 'field-data'],
        'style' => 'display: none;',
      ],
    ];

    $form['ajax_wrapper']['daily_average_volume']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      '#markup' => $this->t('Daily average trading volume') . ' <span class="description">' . $this->t('(Yen equivalent)') . '</span>',
    ];

    $form['ajax_wrapper']['daily_average_volume']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part'], 'id' => ['daily-average-volume']],
      '#markup' => '<div class="count-value"><h4>143,050 ' . $this->t('Yen') . '</h4></div>',
    ];
    $form['expenses_header'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-header-row', 'mt-4']],
      'content' => [
        '#markup' => $expenses_title,
      ],
    ];

    $form['room_preparation_fee'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row']],
    ];

    $form['room_preparation_fee']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => $dpc_room_preparation_text,
      ],
    ];

    $form['room_preparation_fee']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part'], 'id' => ['room-preparation-fee']],
    ];
    $form['room_preparation_fee']['right_part']['room_preparation_fee_select'] = [
      '#type' => 'select',
      '#title' => $dpc_room_preparation_select_text,
      '#options' => $this->calculatorService->getTaxonomyTermsByVid('room_preparation_and_cleaning_fe', NULL, 'dpc'),
      '#attributes' => ['class' => ['form-select', 'preparation-and-cleaning-select']],
    ];

    $form['initial_investment'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row']],
    ];

    $form['initial_investment']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => $dpc_initial_investment_text,
      ],
    ];

    $form['initial_investment']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part'], 'id' => ['initial-investment']],
    ];

    $form['initial_investment']['right_part']['initial_investment_select'] = [
      '#type' => 'select',
      '#title' => $dpc_initial_investment_select_text,
      '#options' => $this->calculatorService->getTaxonomyTermsByVid('initial_investment', NULL, 'dpc'),
      '#attributes' => ['class' => ['form-select', 'initial-investment-select']],
    ];

    $form['others'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-header-row', 'mt-4']],
      'content' => [
        '#markup' => $dpc_others_label,
      ],
    ];
    $form['coefficients'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row']],
    ];

    $form['coefficients']['left_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['left-part']],
      'content' => [
        '#markup' => $dpc_coefficients_text,
      ],
    ];

    $form['coefficients']['right_part'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['right-part'], 'id' => ['coefficients']],
    ];

    $form['coefficients']['right_part']['coefficients_select'] = [
      '#type' => 'select',
      '#title' => $dpc_coefficients_select_text,
      '#options' => $this->calculatorService->getTaxonomyTermsByVid('coefficients', NULL, 'dpc'),
      '#attributes' => ['class' => ['form-select', 'coefficients-select']],
    ];

    $form['table_parent'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-body-row last']],
    ];
    $terms = $this->calculatorService->getTaxonomyTermsByVid('intial_investment_items', NULL, 'dpc');
    $terms_markup = '<ul>';
    foreach ($terms as $term) {
      $terms_markup .= '<li>' . $this->t($term) . '</li>';
    }
    $terms_markup .= '</ul>';

    $form['table_parent']['table_footer'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['table-footer']],
      'content' => [
        '#markup' => '<p><strong>' . $items_required_description . '</strong></p>' . $terms_markup,
      ],
    ];
    $form['actions'] = [
      '#type' => 'container',
      '#attributes' => ['class' => ['form-action']],
    ];

    $form['actions']['button'] = [
      '#type' => 'button',
      '#value' => $run_simulation_text,
      '#attributes' => ['class' => ['btn', 'btn-primary', 'form-control', 'dpc-calculator-submit']]
    ];
    $form['#attached']['library'][] = 'rlt_volume_calculator_items/simulation';
    $form['#attached']['drupalSettings']['rlt_dpc_calculator'] = [
      'lutaterra_cost' => $config->get('lutaterra_cost'),
      'liza_care_cost' => $config->get('liza_care_cost'),
      'granisetron_cost' => $config->get('granisetron_cost'),
    ];
    return $form;
  }

  /**
   * Ajax callback to update medical fee points and daily average volume.
   */
  public function updateMedicalFeePoints(array &$form, FormStateInterface $form_state) {
    $config = $this->configFactory->get('rlt_volume_calculator_items.dpc_settings');
    $dpc_reimbursement_points_right_text = $config->get('dpc_reimbursement_points_right_text') != null ? $this->t($config->get('dpc_reimbursement_points_right_text')) : $this->t('Points (Length of hospital stay)');
    $length_of_hospital = $form_state->getValue(['right_part']);
    if(!empty($length_of_hospital) && is_numeric($length_of_hospital)) {
      $calculatePoints = $this->calculatorService->calculateMedicalFeePointsDpc($length_of_hospital);
      $dpc_medical_fee_points = $calculatePoints['medical_fee_points'];
      $daily_average_volume = $calculatePoints['daily_average_volume'];
      $form['ajax_wrapper']['dpc_medical_fee_points']['right_part']['#markup'] = '<div class="dpc-medical-fee-points-wrapper d-flex align-items-center gap-2"><h4>' . $dpc_medical_fee_points . '</h4><span class="description">' . $dpc_reimbursement_points_right_text . '</span></div>';
      $form['ajax_wrapper']['daily_average_volume']['right_part']['#markup'] = '<div class="dpc-medical-fee-points-wrapper"><h4>' . $daily_average_volume . ' ' . $this->t('Yen') . '</h4></div>';
    } else {
      $form['ajax_wrapper']['dpc_medical_fee_points']['right_part']['#markup'] = '<div class="dpc-medical-fee-points-wrapper d-flex align-items-center gap-2"></div>';
      $form['ajax_wrapper']['daily_average_volume']['right_part']['#markup'] = '<div class="dpc-medical-fee-points-wrapper"></div>';
    }
    $response = new AjaxResponse();
    $response->addCommand(new CssCommand('#block-rltdpcsimulationblock, .download-pdf-wrapper', ['display' => 'none']));
    $response->addCommand(new HtmlCommand('#ajax-wrapper-dpc', $form['ajax_wrapper']));
    return $response;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * Ajax callback to hide the block.
   */
  public function hideBlockOnDpcChange(array &$form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
    $selected_value = $form_state->getValue(['right']);
    $this->handleBlockDpcVisibility($response, $selected_value);
    return $response;
  }

  /**
   * Handles block visibility based on the selected value.
   */
  protected function handleBlockDpcVisibility(AjaxResponse $response, $selected_value) {
    if ($selected_value == 'Volume calculation') {
      $response->addCommand(new InvokeCommand('#block-rltdpccalculator', 'hide'));
      $response->addCommand(new InvokeCommand('#block-rltdpcsimulationblock', 'hide'));
      $response->addCommand(new InvokeCommand('#block-rltvolumecalculator', 'show'));
      $response->addCommand(new InvokeCommand('#block-rltdpcsimulationblock', 'hide'));
    }
  }

}