(function ($, Drupal, drupalSettings) {
  Drupal.behaviors.simulation = {
    attach: function (context, settings) {
      // RLT Volume calculator logic starts.
      // Hide the simulation block on changing preparation and cleaning value.
      $("#rlt-volume-calculator .preparation-and-cleaning-select").on("change", function (e) {
        $('#block-rltstimulationblock').css('display', 'none');
        $('.download-pdf-wrapper').css('display', 'none');
      });
      // Hide the simulation block on changing initial investment value.
      $("#rlt-volume-calculator .initial-investment-select").on("change", function (e) {
        $('#block-rltstimulationblock').css('display', 'none');
        $('.download-pdf-wrapper').css('display', 'none');
      });
      // Update Calculator filter values.
      $('div[id="dpc-component"]').hide();
      $('#edit-right, #edit-right--2').on('change', function () {
        $('.download-pdf-wrapper').hide();
        var selectedValue = $(this).val();
        // Update both selects to have the same value.
        $('#edit-right, #edit-right--2').val(selectedValue);
        // Initial check
        toggleComponents();
        // Listen for changes that might affect visibility
        $('#edit-right, #edit-right--2').on('change', toggleComponents);
        // Optionally, observe DOM changes if visibility is changed elsewhere
        var observer = new MutationObserver(toggleComponents);
        observer.observe(document.body, { attributes: true, childList: true, subtree: true });
      });

      // Toggle visibility of calculator components based on which block is visible.
      function toggleComponents() {
        var vcVisible = $('#block-rltvolumecalculator').css('display') === 'block';
        var dpcVisible = $('#block-rltdpccalculator').css('display') === 'block';
        $('div[id="vc-component"]').toggle(vcVisible);
        $('div[id="dpc-component"]').toggle(dpcVisible);
      }
      // Run simulation submit handler.
      $("#rlt-volume-calculator .volume-calculator-submit").on("click", function (e) {
        e.preventDefault();

        var isFormValid = true;

        // Remove all previous error states first
        $('#rlt-volume-calculator .table-body-row .form-select').removeClass('error')
          .closest('.form-type-select').find('.form-error').remove();
        $('#rlt-volume-calculator .form-submit').prev('.form-error-global').remove();

        $('#rlt-volume-calculator .table-body-row .form-select').each(function () {
          var $select = $(this);
          var losselect = $select.val();
          var isValid = !isNaN(parseFloat(losselect)) && parseInt(losselect) >= 0;

          if (!isValid) {
            isFormValid = false;
            $select.addClass('error');

            var $select2 = $select.next('.select2');
            var errorMessage = Drupal.t('Please select valid options.');
            $('<div class="form-error is-invalid">' + errorMessage + '</div>').insertAfter($select2);
          }
        });

        if (!isFormValid) {
          var errorMessage1 = Drupal.t('There are unselected items.');
          $('<div class="form-error form-error-global is-invalid">' + errorMessage1 + '</div>')
            .insertBefore('#rlt-volume-calculator .form-submit');
          $('#block-rltstimulationblock').css('display', 'none');
          $('.download-pdf-wrapper').css('display', 'none');
          return false;
        }
        $('#block-rltstimulationblock').css('display', 'block'); // Hide the block when invalid'
        $('.download-pdf-wrapper').css('display', 'block');
        // Get the length of stay value.
        var los = $('#rlt-volume-calculator .length-of-stay-select').val();
        // Get the Daily average trading volume value.
        var daily_average_trading = parseFloat($('#rlt-volume-calculator #daily-average-volume h4').text().match(/\d+(\.\d+)?/g).join(''));
        // Get the Room preparation and cleaning fee value.
        var room_preparation_fee = $('#rlt-volume-calculator #room-preparation-fee select').val().replace(/,/g, '');
        // Get the Initial investment value.
        var initial_invest = $('#rlt-volume-calculator #initial-investment select').val().replace(/,/g, '');

        // Calculate the Medical fee per hospitalization (per administration) value.
        var medical_fee_per_hosp = (los * daily_average_trading) - room_preparation_fee;

        // Calculate the Medical fee per case (4 doses) value.
        var medical_fee_per_four = medical_fee_per_hosp * 4;

        // Calculate the Initial investment cost ÷ (medical fee per case) value.
        var no_of_people = Math.ceil(initial_invest / medical_fee_per_four);
        var no_of_doses = Math.ceil(initial_invest / medical_fee_per_hosp);

        // Update Initial investment value.
        $('.volume-calculator-results #result-initial-investment .right-part').text(parseInt(initial_invest).toLocaleString() + ' ' + Drupal.t('yen'));
        // Update Medical fee per hospitalization value.
        $('.volume-calculator-results #fee-block-0 .fee-block-value').text(medical_fee_per_hosp.toLocaleString() + ' ' + Drupal.t('yen'));
        // Update Medical fee per hospitalization value.
        $('.volume-calculator-results #fee-block-1 .fee-block-value').text(medical_fee_per_four.toLocaleString() + ' ' + Drupal.t('yen'));
        // Update Medical fee per hospitalization value.
        $('.volume-calculator-results #fee-block-2 .fee-block-value').text(no_of_people + ' ' + Drupal.t('people'));

        // Update number of people value.
        $('.volume-calculator-header .no-of-people').text(no_of_people);
        // Update number of people value.
        $('.volume-calculator-header .no-of-doses').text(no_of_doses);
        // Loop over the simulation results items table.
        $('.volume-calculator-items tr').each(function () {
          var score = parseFloat($(this).find('.items-score').text().replace(/,/g, ''));
          if (!isNaN(score)) {
            $(this).find('.items-score').text(score.toLocaleString());
            $(this).find('.items-hosp-period-points').text(score.toLocaleString());
          }
          var add_method = $(this).find('.addition-method').text();
          // Update hospital period points value.
          if (!isNaN(score) && add_method == 'D') {
            var points = score * los;
            $(this).find('.items-hosp-period-points').text(points.toLocaleString());
          }
        });
        // Call the function to update the sum initially and whenever needed.
        updateHospPeriodPointsSum();
      });

      // Calculate and display the sum of all 'items-hosp-period-points' values.
      function updateHospPeriodPointsSum() {
        var total = 0;
        $('.volume-calculator-items .items-hosp-period-points').not(':last').each(function () {
          var value = parseFloat($(this).text().replace(/,/g, ''));
          if (!isNaN(value)) {
            total += value;
          }
        });
        // Update the last element with the total sum.
        $('.volume-calculator-items .items-hosp-period-points').last().text(total.toLocaleString());
      }

      // RLT Volume calculator logic ends.

      // RLT DPC calculator logic starts.
      // Hide the simulation block on changing preparation and cleaning value.
      $('#rlt-dpc-calculator #room-preparation-fee select').on("change", function (e) {
        $('#block-rltdpcsimulationblock').css('display', 'none');
        $('.download-pdf-wrapper').css('display', 'none');
      });
      // Hide the simulation block on changing initial investment value.
      $('#rlt-dpc-calculator #initial-investment select').on("change", function (e) {
        $('#block-rltdpcsimulationblock').css('display', 'none');
        $('.download-pdf-wrapper').css('display', 'none');
      });
      // Hide the simulation block on changing Coefficients value.
      $('#rlt-dpc-calculator #coefficients select').on("change", function (e) {
        $('#block-rltdpcsimulationblock').css('display', 'none');
        $('.download-pdf-wrapper').css('display', 'none');
      });

      $("#rlt-dpc-calculator .dpc-calculator-submit").on("click", function (e) {
        e.preventDefault();
        var isFormValid = true;

        // Remove all previous error states first
        $('#rlt-dpc-calculator .table-body-row .form-select').removeClass('error')
          .closest('.form-type-select').find('.form-error').remove();
        $('#rlt-dpc-calculator .form-submit').prev('.form-error-global').remove();

        $('#rlt-dpc-calculator .table-body-row .form-select').each(function () {
          var $select = $(this);
          var losselect = $select.val();
          var isValid = !isNaN(parseFloat(losselect)) && parseInt(losselect) >= 0;

          if (!isValid) {
            isFormValid = false;
            $select.addClass('error');

            var $select2 = $select.next('.select2');
            var errorMessage = Drupal.t('Please select valid options.');
            $('<div class="form-error is-invalid">' + errorMessage + '</div>').insertAfter($select2);
          }
        });

        if (!isFormValid) {
          var errorMessage1 = Drupal.t('There are unselected items.');
          $('<div class="form-error form-error-global is-invalid">' + errorMessage1 + '</div>')
            .insertBefore('#rlt-dpc-calculator .form-submit');
          $('#block-rltdpcsimulationblock').css('display', 'none');
          $('.download-pdf-wrapper').css('display', 'none');
          return false;
        }
        $('#block-rltdpcsimulationblock').css('display', 'block'); // Hide the block when invalid'
        $('.download-pdf-wrapper').css('display', 'block');

        var los = $('#rlt-dpc-calculator .length-of-stay-select').val();
        if (los == 1 || los == 2 || los == 3) {
          $('.dpc-calculator-items .items-tr-3').css('display', 'none');
        } else {
          $('.dpc-calculator-items .items-tr-3').css('display', 'table-row');
        }
        if (los == 1) {
          $('.dpc-calculator-items .items-tr-2').css('display', 'none');
        } else {
          $('.dpc-calculator-items .items-tr-2').css('display', 'table-row');
        }
        // Update the hospital period points value based on score.
        $('.dpc-calculator-items tr').each(function () {
          var score = parseFloat($(this).find('.items-score').text().replace(/,/g, ''));
          if (!isNaN(score)) {
            $(this).find('.items-score').text(score.toLocaleString());
            $(this).find('.items-hosp-period-points').text(score.toLocaleString());
            $(this).find('.dpc-items-remarks-1').text(Drupal.t('Day 1'));
            if (los == 1) {
              $(this).find('.dpc-items-points-2').text(0);
              $(this).find('.dpc-items-points-3').text(0);
            } else if (los == 2) {
              $(this).find('.dpc-items-points-2').text((score).toLocaleString());
              $(this).find('.dpc-items-points-3').text(0);
              $(this).find('.dpc-items-remarks-2').text(Drupal.t('Day 2'));
            } else if (los == 3) {
              $(this).find('.dpc-items-points-2').text((score * 2).toLocaleString());
              $(this).find('.dpc-items-points-3').text(0);
              $(this).find('.dpc-items-remarks-2').text(Drupal.t('Day 2-3'));
            } else if (los == 4) {
              $(this).find('.dpc-items-points-2').text((score * 2).toLocaleString());
              $(this).find('.dpc-items-points-3').text((score).toLocaleString());
              $(this).find('.dpc-items-remarks-2').text(Drupal.t('Day 2-3'));
              $(this).find('.dpc-items-remarks-3').text(Drupal.t('Day 4'));
            } else if (los == 5) {
              $(this).find('.dpc-items-points-2').text((score * 2).toLocaleString());
              $(this).find('.dpc-items-points-3').text((score * 2).toLocaleString());
              $(this).find('.dpc-items-remarks-2').text(Drupal.t('Day 2-3'));
              $(this).find('.dpc-items-remarks-3').text(Drupal.t('Day 4-5'));
            }

            var add_method = $(this).find('.addition-method').text();
            if (add_method == 'D') {
              var points = score * los;
              $(this).find('.items-hosp-period-points').text(points.toLocaleString());
            }
          }
        });

        // Update the Total (points) during the length of hospitalization value.
        var medical_fee_point = $('#rlt-dpc-calculator #medical-fee-points h4').text();
        $('.dpc-calculator-items tr .dpc-items-points-6').text(medical_fee_point);

        // Update the values for Comprehensive evaluation part.
        var point1 = $('.dpc-calculator-items tr .dpc-items-points-1').text();
        var point2 = $('.dpc-calculator-items tr .dpc-items-points-2').text();
        var point3 = $('.dpc-calculator-items tr .dpc-items-points-3').text();
        var comp_total = parseFloat(point1.replace(/,/g, '')) + parseFloat(point2.replace(/,/g, '')) + parseFloat(point3.replace(/,/g, ''));
        $('.dpc-calculator-items tr .dpc-items-points-7').text(comp_total.toLocaleString());

        // Update the values for Volume Portion Total.
        var point4 = $('.dpc-calculator-items tr .dpc-items-points-4').text();
        var point5 = $('.dpc-calculator-items tr .dpc-items-points-5').text();
        var portion_total = parseFloat(point4.replace(/,/g, '')) + parseFloat(point5.replace(/,/g, ''));
        $('.dpc-calculator-items tr .dpc-items-points-8').text(portion_total.toLocaleString());

        // Get the Initial investment value.
        var initial_invest = $('#rlt-dpc-calculator #initial-investment select').val().replace(/,/g, '');
        // Update Initial investment value.
        $('#dpc-result-initial-investment .right-part').text(parseInt(initial_invest).toLocaleString() + ' ' + Drupal.t('yen'));

        // Update the Comprehensive evaluation portion per hospitalization value.
        var coefficients = $('#rlt-dpc-calculator #coefficients select').val();

        var lutaterra_cost = drupalSettings.rlt_dpc_calculator.lutaterra_cost;
        var liza_care_cost = drupalSettings.rlt_dpc_calculator.liza_care_cost;
        var granisetron_cost = drupalSettings.rlt_dpc_calculator.granisetron_cost;
        var drug_cost = parseFloat(lutaterra_cost) + parseFloat(liza_care_cost) + parseFloat(granisetron_cost);

        // Get the Room preparation and cleaning fee value.
        var room_preparation_fee = $('#rlt-dpc-calculator #room-preparation-fee select').val().replace(/,/g, '');
        var eval_portion_hosp = (((parseFloat(comp_total) * 10 * parseFloat(coefficients)) + (parseFloat(portion_total) * 10)) - (drug_cost + parseFloat(room_preparation_fee)));
        var rounded_eval_portion_hosp = eval_portion_hosp > 0 ? Math.ceil(eval_portion_hosp) : Math.floor(eval_portion_hosp);
        $('.simulation-result-body .fee-block #fee-block-0 h4').text(rounded_eval_portion_hosp.toLocaleString() + ' ' + Drupal.t('yen'));

        // Update the Comprehensive evaluation portion per case value.
        var eval_portion_case = eval_portion_hosp * 4;
        var rounded_eval_portion_case = eval_portion_case > 0 ? Math.ceil(eval_portion_case) : Math.floor(eval_portion_case);
        $('.simulation-result-body .fee-block #fee-block-1 h4').text(rounded_eval_portion_case.toLocaleString() + ' ' + Drupal.t('yen'));

        // Calculate the Initial investment cost ÷ (medical fee per case) value.
        var no_of_people = Math.ceil(initial_invest / eval_portion_case);
        var no_of_doses = Math.ceil(initial_invest / eval_portion_hosp);

        // Update Medical fee per hospitalization value.
        $('.simulation-result-body .fee-block #fee-block-2 .fee-block-value').text(no_of_people + ' ' + Drupal.t('people'));

        // Update number of people value.
        $('.dpc-calculator-header .no-of-people').text(no_of_people);
        // Update number of people value.
        $('.dpc-calculator-header .no-of-doses').text(no_of_doses);

      });

      // RLT DPC calculator logic ends.
      $('.form-select').on('change', function () {
        var val = $(this).val();
        if (!isNaN(parseFloat(val)) && parseInt(val) > 0) {
          $(this).removeClass('error')
            .closest('.form-type-select')
            .find('.form-error')
            .remove();

          // Check which calculator the change event belongs to and remove the global error accordingly
          var calculator = $(this).closest('#rlt-volume-calculator, #rlt-dpc-calculator');
          calculator.find('.form-submit').prev('.form-error-global').remove();
        }
      });

      // Pluvicto: Run simulation submit handler.
      $("#rlt-pluvicto-volume-calculator .preparation-and-cleaning-select").on("change", function (e) {
        $('#block-rltpluvictosimulationblock').css('display', 'none');
        $('.download-pdf-wrapper').css('display', 'none');
      });
      // Hide the simulation block on changing initial investment value.
      $("#rlt-pluvicto-volume-calculator .initial-investment-select").on("change", function (e) {
        $('#block-rltpluvictosimulationblock').css('display', 'none');
        $('.download-pdf-wrapper').css('display', 'none');
      });
      $("#rlt-pluvicto-volume-calculator .pluvicto-calculator-submit").on("click", function (e) {
        e.preventDefault();
        var isFormValid = true;
        // Remove all previous error states first
        $('#rlt-pluvicto-volume-calculator .table-body-row .form-select').removeClass('error')
          .closest('.form-type-select').find('.form-error').remove();
        $('#rlt-pluvicto-volume-calculator .form-submit').prev('.form-error-global').remove();

        $('#rlt-pluvicto-volume-calculator .table-body-row .form-select').each(function () {
          var $select = $(this);
          var losselect = $select.val();
          var isValid = !isNaN(parseFloat(losselect)) && parseInt(losselect) >= 0;
          if (!isValid) {
            isFormValid = false;
            $select.addClass('error');

            var $select2 = $select.next('.select2');
            var errorMessage = Drupal.t('Please select valid options.');
            $('<div class="form-error is-invalid">' + errorMessage + '</div>').insertAfter($select2);
          }
        });
        if (!isFormValid) {
          var errorMessage1 = Drupal.t('There are unselected items.');
          $('<div class="form-error form-error-global is-invalid">' + errorMessage1 + '</div>')
            .insertBefore('#rlt-pluvicto-volume-calculator .form-submit');
          $('#block-rltpluvictosimulationblock').css('display', 'none');
          $('.download-pdf-wrapper').css('display', 'none');
          return false;
        }
        $('#block-rltpluvictosimulationblock').css('display', 'block');
        $('.download-pdf-wrapper').css('display', 'block');
        // Get the length of stay value.
        var los = $('#rlt-pluvicto-volume-calculator .length-of-stay-select').val();
        // Update the Total (points) during the length of hospitalization value.
        var medical_fee_point = parseFloat($('#rlt-pluvicto-volume-calculator #medical-fee-points h4').text().match(/\d+(\.\d+)?/g).join(''));
        // Get the Daily average trading volume value.
        var daily_average_trading = parseFloat($('#rlt-pluvicto-volume-calculator #daily-average-volume h4').text().match(/\d+(\.\d+)?/g).join(''));
        // Get the Room preparation and cleaning fee value.
        var room_preparation_fee = $('#rlt-pluvicto-volume-calculator #room-preparation-fee select').val().replace(/,/g, '');
        // Get the Initial investment value.
        var initial_invest = $('#rlt-pluvicto-volume-calculator #initial-investment select').val().replace(/,/g, '');

        // Calculate the Medical fee per hospitalization (per administration) value.
        var medical_fee_per_hosp = (medical_fee_point * 10) - room_preparation_fee;
        // Calculate the Medical fee per case (6 doses) value.
        var medical_fee_per_four = medical_fee_per_hosp * 6;

        // Calculate the Initial investment cost ÷ (medical fee per case) value.
        var no_of_people = (initial_invest / medical_fee_per_four) > 0
          ? Math.ceil(initial_invest / medical_fee_per_four)
          : Math.floor(initial_invest / medical_fee_per_four);
        var no_of_doses = no_of_people * 6;

        // Update Initial investment value.
        $('.pluvicto-volume-calculator-results #result-initial-investment .right-part').text(parseInt(initial_invest).toLocaleString() + ' ' + Drupal.t('yen'));
        // Update Medical fee per hospitalization value.
        $('.pluvicto-volume-calculator-results #fee-block-0 .fee-block-value').text(medical_fee_per_hosp.toLocaleString() + ' ' + Drupal.t('yen'));
        // Update Medical fee per hospitalization value.
        $('.pluvicto-volume-calculator-results #fee-block-1 .fee-block-value').text(medical_fee_per_four.toLocaleString() + ' ' + Drupal.t('yen'));
        // Update Medical fee per hospitalization value.
        $('.pluvicto-volume-calculator-results #fee-block-2 .fee-block-value').text(no_of_people + ' ' + Drupal.t('people'));

        // Update number of people value.
        $('.pluvicto-volume-calculator-header .no-of-people').text(no_of_people);
        // Update number of people value.
        $('.pluvicto-volume-calculator-header .no-of-doses').text(no_of_doses);
        // Loop over the simulation results items table.
        $('.pluvicto-volume-calculator-items tr').each(function () {
          var score = parseFloat($(this).find('.items-score').text().replace(/,/g, ''));
          if (!isNaN(score)) {
            $(this).find('.items-score').text(score.toLocaleString());
            $(this).find('.items-hosp-period-points').text(score.toLocaleString());
          }
          var add_method = $(this).find('.addition-method').text();
          // Update hospital period points value.
          if (!isNaN(score) && add_method == 'D') {
            var points = score * los;
            $(this).find('.items-hosp-period-points').text(points.toLocaleString());
          } else if (!isNaN(score) && add_method == 'W') {
            // Calculate the number of weeks based on los (length of stay)
            var weekCount = Math.ceil(los / 7);
            var points = score * weekCount;
            $(this).find('.items-hosp-period-points').text(points.toLocaleString());
          }
        });
        // Call the function to update the sum initially and whenever needed.
        updatePluvictoHospPeriodPointsSum();
      });
      // Calculate and display the sum of all 'items-hosp-period-points' values.
      function updatePluvictoHospPeriodPointsSum() {
        var total = 0;
        $('.pluvicto-volume-calculator-items .items-hosp-period-points').not(':last').each(function () {
          var value = parseFloat($(this).text().replace(/,/g, ''));
          if (!isNaN(value)) {
            total += value;
          }
        });
        // Update the last element with the total sum.
        $('.pluvicto-volume-calculator-items .items-hosp-period-points').last().text(total.toLocaleString());
      }
    }
  };
})(jQuery, Drupal, drupalSettings);
