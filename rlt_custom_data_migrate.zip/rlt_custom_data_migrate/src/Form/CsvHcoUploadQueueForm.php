<?php

namespace Drupal\rlt_custom_data_migrate\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\file\Entity\File;

/**
 * Class CsvHcoUploadQueueForm.
 */
class CsvHcoUploadQueueForm extends FormBase {

    /**
     * {@inheritdoc}
     */
    public function getFormId() {
        return 'csv_hco_upload_queue_form';
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(array $form, FormStateInterface $form_state) {
        // Define the file upload field for the CSV file.
        $form['csv_file'] = [
            '#type' => 'file',
            '#title' => $this->t('Upload CSV File'),
            '#description' => $this->t('Upload a CSV file for migration.'),
            '#required' => TRUE,
            '#upload_validators' => [
                'file_validate_extensions' => ['csv'],
            ],
        ];
        $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => $this->t('Upload'),
        ];

        return $form;
    }

    /**
     * {@inheritdoc}
     */
    public function validateForm(array &$form, FormStateInterface $form_state) {
        parent::validateForm($form, $form_state);
        $destination = 'public://';
        if($file = file_save_upload('csv_file', $form['csv_file']['#upload_validators'], FALSE, 0)) {
            $original_name = $file->getFilename();
            $file_extension = pathinfo($original_name, PATHINFO_EXTENSION);
            $file_label = pathinfo($original_name, PATHINFO_FILENAME);
            $new_name = $file_label . '_' . time() . '.' . $file_extension;
            $destination_url = \Drupal::service('file_system')->copy(
                $file->getFileUri(),
                $destination . $new_name,
                FileSystemInterface::EXISTS_REPLACE
            );
            $new_file = File::create([
                'uri' => $destination_url,
                'status' => 1
            ]);
            $new_file->save();
            $file_path = $new_file->getFileUri();
            if(($handle = fopen($file_path, 'r')) !== FALSE) {
                $headers = fgetcsv($handle);
                fclose($handle);
                $expected = ['Hospital Name'];
                $missing = array_diff($expected, $headers);
                if(!empty($missing)) {
                    $form_state->setErrorByName('csv_file', $this->t('Missing required column(s): @missing', 
                    ['@missing' => implode(', ', $missing),]));
                }
            } else {
                $form_state->setErrorByName('csv_file', $this->t('Unable to read the uploaded CSV file.'));
            }
        }
        $this->file = $new_file;
    }

    /**
     * {@inheritdoc}
     */
    public function submitForm(array &$form, FormStateInterface $form_state) {
        // Remove the older queue item.
        $old_queue = \Drupal::queue('rlt_csv_migrate_hco');
        while($item = $old_queue->claimItem()) {
            $old_queue->deleteItem($item);
            \Drupal::logger('rlt_queue_worker_hco')->info('Older queue @item is deleted', ['@item' => print_r($item, TRUE)]);
        }
        // Retrieve the uploaded file object.
        $file = $this->file;
        $destination = $file->getFileUri();
        // Update the migration configuration with the new file path.
        \Drupal::configFactory()->getEditable('migrate_plus.migration.rlt_csv_migrate_hco')
            ->set('source.path', $destination)
            ->save();

        // Notify the user that the file was uploaded successfully and the migration path was updated.
        $this->messenger()->addMessage($this->t('CSV file uploaded successfully and migration path updated.'));
        
        // Add a new item to the queue for processing the migration.
        $queue = \Drupal::queue('rlt_csv_migrate_hco');
        $queue->createItem([
            'migration_id' => 'rlt_csv_migrate_hco',
            'triggered_by' => 'manual',
        ]);

        // Rebuild the form to reset its state.
        $form_state->setRebuild(TRUE);
    }

}