<?php

namespace Drupal\rlt_custom_data_migrate\EventSubscriber;

use Drupal\migrate\Event\MigrateEvents;
use Drupal\migrate\Event\MigratePostRowSaveEvent;
use Drupla\migrate\Event\MigratePostImportEvent;
use Drupla\migrate\Event\MigrateImportEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class MigrationLogSubscriber implements EventSubscriberInterface {
    protected $count = 0;
    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents() {
        return [
            MigrateEvents::POST_ROW_SAVE => 'onPostRowSave',
            MigrateEvents::POST_IMPORT => 'onPostImport'
        ];
    }

    /**
     * Increment the count on every HCO created.
     */
    public function onPostRowSave(MigratePostRowSaveEvent $event) {
        $this->count++;
    }

    /**
     * Log the total number of HCOs created.
     */
    public function onPostImport() {
        \Drupal::logger('rlt_csv_migrate_hco')->notice('@count HCO records are created by migration script', ['@count' => $this->count]);
    }
}