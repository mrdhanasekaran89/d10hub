<?php
namespace Drupal\rlt_custom_data_migrate\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\migrate\MigrateExecutable;
use Drupal\migrate\MigrateMessage;
use Drupal\migrate\Plugin\MigrationPluginManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * A Queue Worker to run the migration rlt_custom_data_migrate.
 *
 * @QueueWorker(
 *   id = "rlt_csv_migrate_hco",
 *   title = @Translation("RLT CSV Migrate Hco Queue Worker"),
 *   cron = {"time" = 60}
 * )
 */
class RltCsvMigrateHcoQueueWorker extends QueueWorkerBase {
    /**
     * {@inheritdoc}
     */
    public function processItem($data) {
        // Get the migration plugin manager service.
        $migration_plugin_manager = \Drupal::service('plugin.manager.migration');
        if ($migration_plugin_manager instanceof MigrationPluginManagerInterface) {
            // Load the migration plugin.
            $migration = $migration_plugin_manager->createInstance('rlt_csv_migrate_hco');
            if ($migration) {
                // Run the migration.
                $executable = new MigrateExecutable($migration, new MigrateMessage());
                $executable->import();
            } else {
                \Drupal::logger('rlt_queue_worker_hco')->error('Migration plugin not found: rlt_csv_migrate_hco');
            }
        } else {
            \Drupal::logger('rlt_queue_worker_hco')->error('Invalid migration plugin manager service.');
        }
    }
}
