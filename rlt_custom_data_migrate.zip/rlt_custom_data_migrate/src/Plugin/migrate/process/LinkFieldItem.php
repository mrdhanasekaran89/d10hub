<?php

namespace Drupal\rlt_custom_data_migrate\Plugin\migrate\process;

use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\ProcessPluginBase;
use Drupal\migrate\Row;
use Drupal\migrate\Plugin\migrate\process\MigrationLookup;

/**
 * Validate the link field and pass to the migration.
 *
 * @MigrateProcessPlugin(
 *   id = "link_field_item"
 * )
 */
class LinkFieldItem extends MigrationLookup{
    /**
     * Transforms the given data to the link field.
     */
    public function transform($value, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {
        if (!empty($value)) {
            $url_parts = parse_url($value);
            if(!empty($url_parts) && !empty($url_parts['scheme']) && in_array($url_parts['scheme'], ['http', 'https'])) {
                return [
                    'uri' => $value,
                ];
            }
        } else {
            return [
                'uri' => '',
            ];
        }
    }
}