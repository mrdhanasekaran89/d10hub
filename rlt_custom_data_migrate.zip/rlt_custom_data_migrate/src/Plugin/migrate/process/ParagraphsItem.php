<?php

namespace Drupal\rlt_custom_data_migrate\Plugin\migrate\process;

use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\ProcessPluginBase;
use Drupal\migrate\Row;
use Drupal\migrate\Plugin\migrate\process\MigrationLookup;
use Drupal\paragraphs\Entity\Paragraph;

/**
 * Parses paragraph strings into arrays.
 *
 * @MigrateProcessPlugin(
 *   id = "paragraphs_item"
 * )
 */
class ParagraphsItem extends MigrationLookup{
    /**
     * Transforms the given data to the paragraph.
     */
    public function transform($value, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {
        $paragraphs = [];
        $links = explode(';', $value);
        foreach($links as $item) {
            [$link_type, $uri] = explode('|', $item);
            $paragraph = Paragraph::create([
                'type' => 'hco_supporting_links',
                'link_type' => ['target_id' => $this->lookupTermId($link_type)],
                'link' => [
                    'uri' => $uri,
                ],
            ]);
            $paragraph->save();
            $paragraphs[] = [
                'target_id' => $paragraph->id(),
                'target_revision_id' => $paragraph->getRevisionId()
            ];
        }
        return $paragraphs;
    }

    /**
     * Get the term id from link types.
     */
    protected function lookupTermId($name) {
        $terms = \Drupal::entityTypeManager()
            ->getStorage('taxonomy_term')
            ->loadByProperties(['name' => $name, 'vid' => 'link_types']);
        $term = reset($terms);
        return $term ? $term->id() : NULL;
    }
}