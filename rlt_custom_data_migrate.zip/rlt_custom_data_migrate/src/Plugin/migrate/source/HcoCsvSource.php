<?php
namespace Drupal\rlt_custom_data_migrate\Plugin\migrate\source;

use Drupal\migrate_source_csv\Plugin\migrate\source\CSV;
use Drupal\migrate\Row;

/**
 * Custom CSV source plugin to set dynamic ids.
 *
 * @MigrateSource(
 *   id = "hco_csv_source"
 * )
 */
class HcoCsvSource extends CSV {
    /**
     * {@inheritdoc}
     */
    public function prepareRow(Row $row) {
        $last_insert_id = \Drupal::entityQuery('node')
            ->sort('nid', 'DESC')
            ->range(0,1)
            ->accessCheck(FALSE)
            ->execute();

        $id = reset($last_insert_id);

        $row->setSourceProperty('ID', $id+1);
        return parent::prepareRow($row);
    }
}